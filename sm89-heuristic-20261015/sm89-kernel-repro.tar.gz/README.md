# SM89 packed GDN decode reproduction

Baseline: vllm-project/vllm fc8e08a2a607968226376c53a30cfa6337578f79.
Apply candidate.patch to a second checkout of this commit.

Use an isolated CUDA-enabled environment. Mount baseline checkout at /baseline,
candidate at /source, these helpers at /helpers, writable results at /results,
and a uv-managed virtualenv at /cache/.venv. Select an idle SM89 device.
Recorded environment: L20, Torch 2.13.0+cu129, Triton 3.7.1, vLLM 0.27.1+cu129,
FlashInfer 0.6.16.post3, Python 3.12.3. The exact new decode module is imported
with recorded image dependencies; this is not a full latest-main build.

Commands:

```sh
CUDA_VISIBLE_DEVICES=0 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 uv run --offline --no-project /cache/.venv/bin/python /helpers/run_gpu_pytest.py
CUDA_VISIBLE_DEVICES=0 uv run --offline --no-project /cache/.venv/bin/python /helpers/actual_dispatch_bench.py --shared-timing-storage --output /results/actual-shared.jsonl
```

The actual wrappers choose tiles normally. Case is reused from sweep.py, but
forced-tile functions in that module are never used by this benchmark.
Separate buffers are used for correctness; identical state/output addresses
are used for timing. Seven paired rounds, 60 samples per arm; randomized order.
Torch CUDA 12.9 CUPTI/Kineto records target-kernel durations with CUDA Graph.
Flush 2xL2 before every replay; flushing is excluded from kernel timestamps.
Output and full state are checked before timing. Results are kernel-only.
AI-assisted implementation/testing/analysis. No hardware UUIDs or host addresses.
