"""Build a fresh, owned runtime without modifying reused dependencies."""

import json
from pathlib import Path
import subprocess

runtime = Path('/cache/gdn-runtime')
subprocess.run(['uv', 'venv', '--python', '/study/.venv/bin/python', str(runtime)], check=True)
site = runtime / 'lib/python3.12/site-packages'
origins = [Path('/study/.venv/lib/python3.12/site-packages'),
           Path('/usr/local/lib/python3.12/dist-packages')]
linked = {}
for origin in origins:
    for entry in origin.iterdir():
        name = entry.name
        if (name.startswith(('flashinfer', '__editable__', '_virtualenv',
                             'cutlass', 'nvidia_cutlass', 'cuda', 'nvidia_cuda'))
                or name in {'vllm', '__pycache__', 'nvidia'}):
            continue
        target = site / name
        if target.exists() or target.is_symlink():
            continue
        target.symlink_to(entry, target_is_directory=entry.is_dir())
        linked[name] = str(entry)
for name in ('flashinfer', 'flashinfer_python-0.7.0.post1.dist-info'):
    entry = Path('/oldcache/runtime-addons') / name
    (site / name).symlink_to(entry, target_is_directory=entry.is_dir())
Path('/results/runtime-links.json').write_text(json.dumps(linked, indent=2) + '\n')
print('OWN_RUNTIME_ASSEMBLED', len(linked), flush=True)
