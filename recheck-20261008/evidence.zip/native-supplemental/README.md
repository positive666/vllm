This artifact builds the official vLLM GDN post-convolution MTP CUDA kernel as
a separate native library for L20 (SM89). It supplements a CUDA12.9 native
runtime in which the op is absent. It is **not** a full main vLLM CUDA13 build;
the regular main CMake CUDA>=13 selection remains untested.

The builder copies the kernel, torch_utils.h, and cuda_compat.h byte for byte
from `--source-root`. It extracts the official function prototype, schema,
and CUDA STABLE_IMPL registration block without changing their text, adding
only a minimal registration translation-unit shell. It records source and
library SHA256 hashes, registration mapping, flags, compiler version, Torch,
and GPU capability. Compiler flags use C++20, USE_CUDA,
TORCH_TARGET_VERSION=0x020B000000000000ULL, --use_fast_math, and SM89, matching
the relevant main build settings. It builds with at most two jobs using
torch.utils.cpp_extension.load(is_python_module=False).

For affected Torch 2.13 headers, the repository's existing string ownership
patch is applied to an owned shadow include copy. Installed Torch headers
remain untouched. A build failure is retained in build-manifest.json and is
not converted to a successful test.

Example inside an owned experiment container (replace COMMIT with the exact
40-digit archived source commit; paths are container mount paths):

```sh
uv run --no-project /cache/gdn-runtime/bin/python \
  /artifacts/native-supplemental/build_native.py \
  --source-root /source --source-commit COMMIT \
  --work-dir /results/native-supplemental

uv run --no-project /cache/gdn-runtime/bin/python \
  /artifacts/native-supplemental/pytest_native.py \
  --source-root /source \
  --manifest /results/native-supplemental/build-manifest.json \
  --suite mtp --report /results/native-supplemental/mtp-pytest.json

uv run --no-project /cache/gdn-runtime/bin/python \
  /artifacts/native-supplemental/pytest_native.py \
  --source-root /source \
  --manifest /results/native-supplemental/build-manifest.json \
  --suite post-conv-head-ratios \
  --report /results/native-supplemental/post-conv-pytest.json
```

The launcher loads the existing vLLM stable native binary, verifies the op was
absent, explicitly loads the supplementary library using torch.ops.load_library,
then verifies the CUDA dispatcher and runs existing pytest files unchanged.
It does not monkeypatch Python ops or test tolerances. Tests' own existing
route-count assertions distinguish native MTP calls from fallback paths.
Skips, errors, and failures are retained. These tests are kernel and model-path
unit validation, not speculative-serving or accuracy evaluation.
