#!/usr/bin/env python
"""Build the official GDN MTP kernel as a supplemental CUDA library.

Run through the owned UV interpreter. This is NOT the main vLLM CMake build.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import traceback


OP = "fused_gdn_decode_post_conv_mtp"
SOURCE_FILES = (
    "csrc/libtorch_stable/gdn/fused_gdn_decode_kernel.cu",
    "csrc/libtorch_stable/torch_utils.h",
    "csrc/cuda_compat.h",
)
REFERENCE_FILES = (
    "csrc/libtorch_stable/ops.h",
    "csrc/libtorch_stable/torch_bindings.cpp",
    "cmake/patches/pytorch_stable_string.patch",
    "CMakeLists.txt",
    "tests/kernels/mamba/test_gdn_fused_mtp.py",
    "tests/kernels/fla/test_fused_gdn_post_conv.py",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def extract_block(text: str, expression: str, description: str) -> tuple[str, int]:
    matches = list(re.finditer(expression, text, re.MULTILINE | re.DOTALL))
    if len(matches) != 1:
        raise RuntimeError(f"Expected one official {description}, got {len(matches)}")
    match = matches[0]
    return match.group(1), text[: match.start(1)].count("\n") + 1


def stage_sources(source: Path, work: Path) -> dict:
    copied = work / "official_source"
    provenance = {}
    for relative in (*SOURCE_FILES, *REFERENCE_FILES):
        origin = source / relative
        destination = copied / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, destination)
        if sha256(origin) != sha256(destination):
            raise RuntimeError(f"Byte copy differs for {relative}")
        provenance[relative] = sha256(origin)

    bindings_path = copied / "csrc/libtorch_stable/torch_bindings.cpp"
    ops_path = copied / "csrc/libtorch_stable/ops.h"
    # read_bytes/decode keeps CRLF intact inside the extracted official blocks.
    bindings = bindings_path.read_bytes().decode("utf-8")
    ops = ops_path.read_bytes().decode("utf-8")
    schema, schema_line = extract_block(
        bindings,
        r"#ifdef VLLM_ENABLE_FUSED_GDN_DECODE\r?\n(  ops\.def\(.*?\);\r?\n)#endif",
        "GDN schema block",
    )
    implementation, impl_line = extract_block(
        bindings,
        r"#ifdef VLLM_ENABLE_FUSED_GDN_DECODE\r?\n(  ops\.impl\(.*?\);\r?\n)#endif",
        "GDN CUDA implementation block",
    )
    prototype, prototype_line = extract_block(
        ops,
        r"#ifdef VLLM_ENABLE_FUSED_GDN_DECODE\r?\n(void "
        + OP
        + r"\(.*?\);\r?\n)\r?\n#endif",
        "GDN function prototype",
    )
    for block in (schema, implementation, prototype):
        if OP not in block:
            raise RuntimeError("Official block does not name the expected op")
    registration = (
        "// Supplemental registration shell; enclosed declarations are copied "
        "verbatim.\n"
        "#include <string>\n"
        "#include <torch/csrc/stable/library.h>\n"
        "#include <torch/csrc/stable/tensor.h>\n\n"
        + prototype
        + "\nSTABLE_TORCH_LIBRARY_FRAGMENT(_C, ops) {\n"
        + schema
        + "}\n\nSTABLE_TORCH_LIBRARY_IMPL(_C, CUDA, ops) {\n"
        + implementation
        + "}\n"
    )
    generated = work / "gdn_supplemental_bindings.cpp"
    generated.write_bytes(registration.encode("utf-8"))
    return {
        "official_source_hashes": provenance,
        "registration_sha256": sha256(generated),
        "registration_blocks": {
            "schema": {
                "file": "csrc/libtorch_stable/torch_bindings.cpp",
                "start_line": schema_line,
                "sha256": hashlib.sha256(schema.encode("utf-8")).hexdigest(),
            },
            "CUDA_impl": {
                "file": "csrc/libtorch_stable/torch_bindings.cpp",
                "start_line": impl_line,
                "sha256": hashlib.sha256(implementation.encode("utf-8")).hexdigest(),
            },
            "prototype": {
                "file": "csrc/libtorch_stable/ops.h",
                "start_line": prototype_line,
                "sha256": hashlib.sha256(prototype.encode("utf-8")).hexdigest(),
            },
        },
    }


def prepare_shadow_header(source: Path, work: Path, torch_version: str) -> dict:
    from torch.utils.cpp_extension import include_paths

    result = {"applied": False}
    version = tuple(int(part) for part in torch_version.split("+")[0].split(".")[:2])
    if not (version >= (2, 13) and version < (2, 14)):
        return result
    relative = Path("torch/csrc/stable/stableivalue_conversions.h")
    installed = Path(include_paths()[0]) / relative
    before = installed.read_bytes()
    result["installed_sha256"] = hashlib.sha256(before).hexdigest()
    if b"auto strptr = new std::string" not in before:
        return result
    shadow = work / "torch_patched_headers"
    destination = shadow / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(before)
    patch = source / "cmake/patches/pytorch_stable_string.patch"
    subprocess.run(
        ["patch", "--batch", "--forward", "-p1", f"--input={patch}"],
        cwd=shadow,
        check=True,
    )
    if installed.read_bytes() != before:
        raise RuntimeError("Installed Torch header changed unexpectedly")
    result.update(
        applied=True,
        owned_shadow_directory=str(shadow),
        patched_sha256=sha256(destination),
        patch_sha256=sha256(patch),
        installed_header_unchanged=True,
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--stage-only", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9a-f]{40}", args.source_commit):
        parser.error("--source-commit must be a complete 40-digit Git commit")
    source = args.source_root.resolve(strict=True)
    work = args.work_dir.resolve()
    work.mkdir(parents=True, exist_ok=True)
    manifest = {
        "scope": "supplemental official GDN MTP kernel, NOT full main CUDA13 build",
        "source_commit": args.source_commit,
        "source_root": str(source),
        "python": sys.executable,
        "test_or_kernel_source_modified": False,
        "normal_main_cmake_requires_cuda_13": True,
        "supplemental_compiler_target": "sm_89",
        "status": "started",
    }
    manifest_path = work / "build-manifest.json"
    try:
        manifest.update(stage_sources(source, work))
        if args.stage_only:
            manifest["status"] = "staged_only_no_build"
            write_json(manifest_path, manifest)
            return 0

        import torch
        from torch.utils.cpp_extension import CUDA_HOME, load

        if CUDA_HOME is None:
            raise RuntimeError("CUDA toolkit not detected")
        nvcc = str(Path(CUDA_HOME) / "bin/nvcc")
        nvcc_version = subprocess.run(
            [nvcc, "--version"], capture_output=True, text=True, check=True
        ).stdout
        manifest.update(
            torch_version=torch.__version__,
            torch_cuda_version=torch.version.cuda,
            cuda_home=CUDA_HOME,
            nvcc_version=nvcc_version,
            gpu_name=torch.cuda.get_device_name(),
            gpu_capability=list(torch.cuda.get_device_capability()),
        )
        if torch.cuda.get_device_capability() != (8, 9):
            raise RuntimeError("This supplemental artifact is limited to L20 SM89")
        shadow = prepare_shadow_header(source, work, torch.__version__)
        manifest["torch_stable_string_shadow"] = shadow
        definitions = [
            "-DTORCH_TARGET_VERSION=0x020B000000000000ULL",
            "-DUSE_CUDA",
        ]
        cpp_flags = ["-O3", "-std=c++20", *definitions]
        cuda_flags = ["-O3", "-std=c++20", "--use_fast_math", *definitions]
        build_dir = work / "build"
        build_dir.mkdir(exist_ok=True)
        os.environ["TORCH_CUDA_ARCH_LIST"] = "8.9"
        os.environ["MAX_JOBS"] = "2"
        include_dirs = []
        if shadow["applied"]:
            include_dirs.append(shadow["owned_shadow_directory"])
        manifest.update(
            cpp_flags=cpp_flags,
            cuda_flags=cuda_flags,
            torch_cuda_arch_list="8.9",
            max_jobs=2,
            build_method="torch.utils.cpp_extension.load(is_python_module=False)",
        )
        write_json(manifest_path, manifest)
        library = load(
            name="gdn_native_supplemental_20261008",
            sources=[
                str(work / "gdn_supplemental_bindings.cpp"),
                str(work / "official_source" / SOURCE_FILES[0]),
            ],
            extra_cflags=cpp_flags,
            extra_cuda_cflags=cuda_flags,
            extra_include_paths=include_dirs,
            build_directory=str(build_dir),
            with_cuda=True,
            is_python_module=False,
            verbose=True,
        )
        library = Path(library).resolve(strict=True)
        manifest.update(
            status="built_and_loaded_in_builder",
            library_path=str(library),
            library_sha256=sha256(library),
            cuda_dispatch_registered=torch._C._dispatch_has_kernel_for_dispatch_key(
                f"_C::{OP}", "CUDA"
            ),
            ninja_sha256=sha256(build_dir / "build.ninja"),
        )
        if not manifest["cuda_dispatch_registered"]:
            raise RuntimeError("Supplemental library did not register a CUDA kernel")
        write_json(manifest_path, manifest)
        print(json.dumps({"status": manifest["status"], "library": str(library)}))
        return 0
    except Exception as exc:
        manifest.update(status="failed", error=f"{type(exc).__name__}: {exc}")
        write_json(manifest_path, manifest)
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
