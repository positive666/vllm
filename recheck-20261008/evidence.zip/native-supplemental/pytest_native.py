#!/usr/bin/env python
"""Load supplemental native .so, then run existing tests without patches."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import traceback


OP = "fused_gdn_decode_post_conv_mtp"
SUITES = {
    "mtp": ("tests/kernels/mamba/test_gdn_fused_mtp.py", []),
    "post-conv-head-ratios": (
        "tests/kernels/fla/test_fused_gdn_post_conv.py",
        ["-k", "head_ratios"],
    ),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--suite", required=True, choices=SUITES)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("pytest_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    source = args.source_root.resolve(strict=True)
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    library = Path(manifest["library_path"]).resolve(strict=True)
    relative, selectors = SUITES[args.suite]
    test_path = source / relative
    report = {
        "scope": "existing tests with supplemental native GDN MTP kernel only",
        "suite": args.suite,
        "source_commit": manifest["source_commit"],
        "python": sys.executable,
        "library_path": str(library),
        "library_sha256": sha256(library),
        "test_file": relative,
        "test_file_sha256": sha256(test_path),
        "python_op_monkeypatched_by_launcher": False,
        "test_tolerance_modified": False,
        "normal_main_cuda13_build_covered": False,
        "test_reports": [],
        "status": "started",
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)

    def save() -> None:
        args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    try:
        if manifest["status"] != "built_and_loaded_in_builder":
            raise RuntimeError("Native build manifest does not record a successful build")
        if report["library_sha256"] != manifest["library_sha256"]:
            raise RuntimeError("Supplemental library differs from the build manifest")
        if report["test_file_sha256"] != manifest["official_source_hashes"][relative]:
            raise RuntimeError("Test differs from the source recorded at build time")
        os.chdir(source)
        sys.path.insert(0, str(source))
        import torch

        # Import the existing binary first; do not overwrite a real existing op.
        old_binary = importlib.import_module("vllm._C_stable_libtorch")
        report["existing_native_binary_path"] = old_binary.__file__
        report["existing_native_binary_sha256"] = sha256(Path(old_binary.__file__))
        report["op_before_supplemental"] = hasattr(torch.ops._C, OP)
        if report["op_before_supplemental"]:
            raise RuntimeError("Existing binary already contains the op; supplemental not needed")
        if torch.cuda.get_device_capability() != (8, 9):
            raise RuntimeError("This supplementary build is restricted to SM89")
        torch.ops.load_library(str(library))
        report.update(
            torch_version=torch.__version__,
            torch_cuda_version=torch.version.cuda,
            gpu_name=torch.cuda.get_device_name(),
            gpu_capability=list(torch.cuda.get_device_capability()),
            op_after_supplemental=hasattr(torch.ops._C, OP),
            cuda_dispatch_registered=torch._C._dispatch_has_kernel_for_dispatch_key(
                f"_C::{OP}", "CUDA"
            ),
            dispatch_table=torch._C._dispatch_dump_table(f"_C::{OP}"),
            op_schema=str(getattr(torch.ops._C, OP).default._schema),
        )
        if not report["cuda_dispatch_registered"]:
            raise RuntimeError("CUDA dispatch kernel is missing")
        save()
        import pytest

        run_report = report

        class Recorder:
            def pytest_runtest_logreport(self, report):
                run_report["test_reports"].append(
                    {
                        "nodeid": report.nodeid,
                        "phase": report.when,
                        "outcome": report.outcome,
                        "duration": report.duration,
                        "detail": str(report.longrepr) if report.longrepr else None,
                    }
                )
                save()

        extra_args = args.pytest_args
        if extra_args and extra_args[0] == "--":
            extra_args = extra_args[1:]
        command = [str(test_path), *selectors, "-vv", "-rs", *extra_args]
        report["pytest_args"] = command
        return_code = int(pytest.main(command, plugins=[Recorder()]))
        torch.cuda.synchronize()
        report.update(status="pytest_finished", pytest_exit_code=return_code)
        reports = report["test_reports"]
        report["counts"] = {
            outcome: sum(
                item["outcome"] == outcome
                and (item["phase"] == "call" or outcome == "skipped")
                for item in reports
            )
            for outcome in ("passed", "failed", "skipped")
        }
        report["setup_or_teardown_failures"] = sum(
            item["outcome"] == "failed" and item["phase"] != "call"
            for item in reports
        )
        save()
        print(json.dumps({"counts": report["counts"], "pytest_exit_code": return_code}))
        return return_code
    except Exception as exc:
        report.update(status="launcher_failed", error=f"{type(exc).__name__}: {exc}")
        save()
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
