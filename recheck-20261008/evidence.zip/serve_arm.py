"""Own-container serving experiment with bounded startup and process cleanup."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=("triton-a1", "flashinfer-b1", "flashinfer-b2", "triton-a2"), required=True)
    parser.add_argument("--quality", action="store_true")
    parser.add_argument("--requests", type=int, default=32)
    parser.add_argument("--attempt", type=int, default=1)
    parser.add_argument("--series", choices=("preliminary", "final"))
    parser.add_argument("--cache-blocks", type=int)
    parser.add_argument("--quality-max-tokens", type=int, default=1024)
    args = parser.parse_args()
    backend = args.arm.split("-")[0]
    launch = args.arm if args.attempt == 1 else f"{args.arm}-attempt{args.attempt}"
    if args.series:
        launch = f"{args.series}-{launch}"
    results = Path("/results") / args.series if args.series else Path("/results")
    results.mkdir(parents=True, exist_ok=True)
    log_path = Path("/logs") / f"serve-{launch}.log"
    evidence_path = results / f"serve-{launch}.json"
    if evidence_path.exists() or log_path.exists():
        raise FileExistsError("Refusing to overwrite a launch")
    env = os.environ.copy()
    env.update(PYTHONPATH="/source", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
               VLLM_CACHE_ROOT=f"/cache/serve-{launch}/vllm",
               TRITON_CACHE_DIR=f"/cache/serve-{launch}/triton",
               CUDA_CACHE_PATH=f"/cache/serve-{launch}/cuda")
    command = ["uv", "run", "--offline", "--no-project", sys.executable, "-m",
               "vllm.entrypoints.openai.api_server", "--model", "/model",
               "--served-model-name", "qwen-fp8", "--host", "127.0.0.1", "--port", "8000",
               "--language-model-only", "--dtype", "bfloat16", "--tensor-parallel-size", "1",
               "--max-model-len", "2048", "--max-num-seqs", "32",
               "--max-num-batched-tokens", "1024", "--gpu-memory-utilization", "0.9",
               "--no-enable-prefix-caching", "--mamba-ssm-cache-dtype", "float32",
               "--seed", "42", "--attention-config",
               json.dumps({"backend": "FLASH_ATTN", "flash_attn_version": 2}),
               "--kernel-config", json.dumps({"gdn_decode_backend": backend, "linear_backend": "marlin"})]
    if args.cache_blocks:
        command.extend(["--num-gpu-blocks-override", str(args.cache_blocks)])
    source_files = {
        name: hashlib.sha256((Path("/source") / name).read_bytes()).hexdigest()
        for name in ("vllm/config/kernel.py", "vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py",
                     "vllm/v1/attention/backends/gdn_attn.py")
    }
    evidence = {"arm": args.arm, "attempt": args.attempt, "backend": backend, "command": command,
                "source_files": source_files,
                "state_dtype": "float32", "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "runtime": json.loads(Path("/results/runtime-probe.json").read_text()),
                "status": "starting"}
    write_json(evidence_path, evidence)
    with log_path.open("x") as log:
        server = subprocess.Popen(command, cwd="/source", env=env, stdout=log,
                                  stderr=subprocess.STDOUT, start_new_session=True)
        evidence["server_pid"] = server.pid
        write_json(evidence_path, evidence)
        try:
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            deadline = time.monotonic() + 900
            while time.monotonic() < deadline:
                if server.poll() is not None:
                    raise RuntimeError(f"Server exited during startup: {server.returncode}")
                try:
                    with opener.open("http://127.0.0.1:8000/health", timeout=2) as response:
                        if response.status == 200:
                            break
                except (urllib.error.URLError, TimeoutError):
                    pass
                time.sleep(3)
            else:
                raise TimeoutError("Server readiness exceeded 900 seconds")
            evidence["status"] = "ready"
            evidence["ready_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            write_json(evidence_path, evidence)
            fixture = results / "http-fixture.json"
            common = ["uv", "run", "--offline", "--no-project", sys.executable]
            if not fixture.exists():
                subprocess.run(common + ["/artifacts/http_bench_client.py", "fixture", "--fixture", str(fixture)], check=True, env=env)
            subprocess.run(common + ["/artifacts/http_bench_client.py", "bench", "--fixture", str(fixture),
                                     "--arm", args.arm, "--output-dir", str(results / "http"),
                                     "--server-evidence", str(evidence_path), "--requests", str(args.requests)],
                           check=True, env=env, timeout=1800)
            if args.quality:
                subprocess.run(common + ["/artifacts/quality_http.py", "--arm", backend,
                                         "--output", str(results / f"quality-{backend}.json"),
                                         "--dataset", "/cache/gsm8k-test.jsonl", "--samples", "100",
                                         "--max-tokens", str(args.quality_max_tokens), "--server-evidence", str(evidence_path)],
                               check=True, env=env, timeout=1800)
            evidence["status"] = "completed"
        except Exception as exc:
            evidence["status"] = "failed"
            evidence["error"] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            # Only the process group created above is affected.
            try:
                os.killpg(server.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                server.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(server.pid, signal.SIGKILL)
                server.wait(timeout=10)
            evidence["server_exit"] = server.returncode
            evidence["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            evidence["server_log_sha256"] = hashlib.sha256(log_path.read_bytes()).hexdigest()
            write_json(evidence_path, evidence)


if __name__ == "__main__":
    main()
