"""Derive an explicitly bounded smoke harness from the frozen benchmark."""

from pathlib import Path

target = Path(__file__).parent
source = target.parent / 'gdn-flashinfer-takeover-20261006'
client = (source / 'http_bench_client.py').read_text(encoding='utf-8')
assert 'if args.requests < 32:' in client
client = client.replace('if args.requests < 32:', 'if args.requests < 8:')
client = client.replace('At least 32 requests per measured round required',
                        'Compatibility smoke requires at least 8 requests')
client = client.replace('PROTOCOL = {',
                        'PROTOCOL = {\n    "purpose": "compatibility smoke; no performance inference",', 1)
client = client.replace('default=32)', 'default=8)')
(target / 'http_smoke_client.py').write_text(client, encoding='utf-8')
supervisor = (source / 'serve_arm.py').read_text(encoding='utf-8')
supervisor = supervisor.replace('/artifacts/http_bench_client.py',
                                '/artifacts/http_smoke_client.py')
supervisor = supervisor.replace('default=32)', 'default=8)')
(target / 'serve_smoke.py').write_text(supervisor, encoding='utf-8')
print('Smoke harness generated; original benchmark unchanged.')
