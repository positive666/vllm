"""Run a matched model-quality screen on the frozen review source."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", choices=("triton", "flashinfer"), required=True)
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--concurrency", type=int, choices=(1, 8), default=8)
    args = parser.parse_args()
    root = Path("/results/quality-followup-20261008")
    root.mkdir(parents=True, exist_ok=True)
    launch = f"{args.backend}-c{args.concurrency}-r{args.repeat}"
    log_path = root / f"supervisor-{launch}.log"
    evidence_path = root / f"supervisor-{launch}.json"
    output_path = root / f"{launch}-quality.json"
    if log_path.exists() or evidence_path.exists() or output_path.exists():
        raise FileExistsError("Refusing to overwrite a quality run")
    manifest = json.loads(Path("/artifacts/quality-followup-source.json").read_text())
    source_hashes = {
        name: hashlib.sha256((Path("/source") / name).read_bytes()).hexdigest()
        for name in manifest["files"]
    }
    assert all(source_hashes[name] == item["sha256"]
               for name, item in manifest["files"].items()), source_hashes
    dataset = Path("/oldcache/gsm8k-test.jsonl")
    assert dataset.is_file(), dataset
    env = os.environ.copy()
    env.update(PYTHONPATH="/source", HF_HUB_OFFLINE="1",
               TRANSFORMERS_OFFLINE="1",
               VLLM_CACHE_ROOT=f"/cache/quality-{launch}/vllm",
               TRITON_CACHE_DIR=f"/cache/quality-{launch}/triton",
               CUDA_CACHE_PATH=f"/cache/quality-{launch}/cuda")
    command = [
        "uv", "run", "--offline", "--no-project", sys.executable, "-m",
        "vllm.entrypoints.openai.api_server", "--model", "/model",
        "--served-model-name", "qwen-fp8", "--host", "127.0.0.1",
        "--port", "8000", "--language-model-only", "--dtype", "bfloat16",
        "--tensor-parallel-size", "1", "--max-model-len", "2048",
        "--max-num-seqs", "32", "--max-num-batched-tokens", "1024",
        "--gpu-memory-utilization", "0.9", "--no-enable-prefix-caching",
        "--mamba-ssm-cache-dtype", "float32", "--seed", "42",
        "--attention-config",
        json.dumps({"backend": "FLASH_ATTN", "flash_attn_version": 2}),
        "--kernel-config",
        json.dumps({"gdn_decode_backend": args.backend, "linear_backend": "marlin"}),
        "--num-gpu-blocks-override", "64",
    ]
    record = {
        "backend": args.backend, "repeat": args.repeat,
        "concurrency": args.concurrency, "source_head": manifest["source_head"],
        "source_files": source_hashes, "command": command,
        "runtime": json.loads(Path("/results/runtime-probe.json").read_text()),
        "runtime_note": "Reused runtime probe from the earlier review run",
        "model_config_sha256": hashlib.sha256(Path("/model/config.json").read_bytes()).hexdigest(),
        "dataset_sha256": hashlib.sha256(dataset.read_bytes()).hexdigest(),
        "supervisor_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "status": "starting",
    }
    write_json(evidence_path, record)
    with log_path.open("x") as handle:
        server = subprocess.Popen(command, cwd="/source", env=env,
                                  stdout=handle, stderr=subprocess.STDOUT,
                                  start_new_session=True)
        record["server_pid"] = server.pid
        write_json(evidence_path, record)
        try:
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            deadline = time.monotonic() + 900
            while time.monotonic() < deadline:
                if server.poll() is not None:
                    raise RuntimeError(f"Server exited during startup: {server.returncode}")
                try:
                    with opener.open("http://127.0.0.1:8000/health", timeout=2) as response:
                        if response.status == 200:
                            break
                except (urllib.error.URLError, TimeoutError):
                    pass
                time.sleep(3)
            else:
                raise TimeoutError("Server readiness exceeded 900 seconds")
            record["status"] = "ready"
            record["ready_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            write_json(evidence_path, record)
            quality_command = [
                "uv", "run", "--offline", "--no-project", sys.executable,
                "/artifacts/quality_http.py", "--arm", args.backend,
                "--output", str(output_path), "--dataset", str(dataset),
                "--samples", "100", "--concurrency", str(args.concurrency),
                "--max-tokens", "1750", "--timeout", "300",
                "--server-evidence", str(evidence_path),
            ]
            record["quality_command"] = quality_command
            write_json(evidence_path, record)
            subprocess.run(quality_command, check=True, env=env, timeout=3600)
            record["status"] = "completed"
            record["quality_sha256"] = hashlib.sha256(output_path.read_bytes()).hexdigest()
        except Exception as exc:
            record["status"] = "failed"
            record["error"] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            try:
                os.killpg(server.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                server.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(server.pid, signal.SIGKILL)
                server.wait(timeout=10)
            record["server_exit"] = server.returncode
            record["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            record["server_log_sha256"] = hashlib.sha256(log_path.read_bytes()).hexdigest()
            write_json(evidence_path, record)


if __name__ == "__main__":
    main()
