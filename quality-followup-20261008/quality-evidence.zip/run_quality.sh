#!/usr/bin/env bash
set -u
quality_exit=0
for backend in triton flashinfer; do
    uv run --offline --no-project /cache/gdn-runtime/bin/python \
        /artifacts/quality_supervisor.py --backend "$backend" \
        > "/results/quality-followup-20261008/client-$backend-c8-r1.log" 2>&1
    arm_exit=$?
    printf '%s\n' "$arm_exit" > "/results/quality-followup-20261008/$backend-c8-r1.exit"
    if [ "$arm_exit" -ne 0 ]; then quality_exit=$arm_exit; fi
done
date -u '+%Y-%m-%dT%H:%M:%SZ' > /results/quality-followup-20261008/run.done
printf '%s\n' "$quality_exit" > /results/quality-followup-20261008/run.exit
exit "$quality_exit"
