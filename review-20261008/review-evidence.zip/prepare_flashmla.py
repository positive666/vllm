"""Generate the pinned FlashMLA wrapper as current-main CMake does."""

import hashlib
import json
from pathlib import Path

original = Path("/oldcache/generated/flashmla-upstream.py")
original_sha = hashlib.sha256(original.read_bytes()).hexdigest()
assert original_sha == "76eb66a7922531f402ce6fadd51e01aab19b84bff063d2b33dfbaa68f8915e26"
cmake = Path("/source/cmake/external_projects/flashmla.cmake").read_text()
commit = "0eee43b12f034b657133cf2afca6a72ebb6efccf"
assert f"GIT_TAG {commit}" in cmake
needle = "flash_mla_cuda = torch.ops._flashmla_C"
content = original.read_text()
assert content.count(needle) == 1
target = Path("/source/vllm/third_party/flashmla/flash_mla_interface.py")
assert not target.exists()
target.write_text(content.replace(needle, "import vllm._flashmla_C\n" + needle))
record = {
    "source_commit": commit,
    "generation": "cmake/external_projects/flashmla.cmake string replacement",
    "original_sha256": original_sha,
    "generated_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
    "target": str(target),
    "note": "Generated dependency wrapper only; no FlashMLA GPU kernels used on SM89",
}
Path("/results/flashmla-generated.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
