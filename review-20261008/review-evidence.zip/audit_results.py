"""Audit core checks and completed serving retries without using timings as gains."""

import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--results", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent
manifest = json.loads((root / "source-manifest.json").read_text())
results = args.results.resolve()


def read_json(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


counts = {}
for suite, expected in (("adapter-and-split", 40), ("gdn-metadata", 63), ("gdn-config", 1)):
    cases = list(ET.parse(results / f"{suite}.xml").getroot().iter("testcase"))
    assert len(cases) == expected
    assert not any(case.find(tag) is not None for case in cases for tag in ("failure", "error", "skipped"))
    assert (results / f"{suite}.exit").read_text().strip() == "0"
    counts[suite] = len(cases)
runtime = read_json(results / "runtime-probe.json")
assert runtime["declared_source_head"] == manifest["source_head"]
for name, recorded in runtime["source_files"].items():
    assert recorded["sha256"] == manifest["files"][name]["sha256"]
assert runtime["record_integrity_failures"] == []
probes = {}
for mode, expected_error in ((0, "BufferError"), (1, "ValueError")):
    record = read_json(results / f"param-export-{mode}.json")
    assert record["adapter"]["status"] == "passed"
    assert record["adapter"]["original_helper_assertions_passed"]
    assert record["adapter"]["input_parameters_still_require_grad"]
    assert record["raw_fi"]["error"]["type"] == expected_error
    assert record["adapter_source"]["sha256"] == manifest["files"]["vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py"]["sha256"]
    assert record["helper_source"]["sha256"] == manifest["files"]["tests/kernels/fla/test_fused_sigmoid_gating_delta_rule.py"]["sha256"]
    probes[str(mode)] = {
        "raw_fi_error_type": expected_error,
        "raw_fi_error_message": record["raw_fi"]["error"]["message"],
        "adapter_status": record["adapter"]["status"],
        "max_output_abs_error": record["adapter"]["max_output_abs_error"],
    }
override = read_json(results / "override-log-probe.json")
assert override["status"] == "passed" and override["message_count"] == 1
assert (results / "serving-retry.exit").read_text().strip() == "0"

arms = {}
totals = {"measured": 0, "warmup": 0}
fixtures = set()
protocols = set()
for arm in ("triton-a1", "flashinfer-b1"):
    launch = read_json(results / "final" / f"serve-final-{arm}-attempt2.json")
    assert launch["status"] == "completed" and launch["server_exit"] == 0
    log = results / "logs" / f"serve-final-{arm}-attempt2.log"
    assert sha(log) == launch["server_log_sha256"]
    for name, recorded in launch["source_files"].items():
        assert recorded == manifest["files"][name]["sha256"]
    cache_sizes = re.findall(r"GPU KV cache size: ([\d,]+) tokens", log.read_text())
    assert cache_sizes and set(cache_sizes) == {"21,845"}
    record = read_json(results / "final" / "http" / f"{arm}.json")
    assert record["all_successful"]
    fixtures.add(record["fixture_sha256"])
    protocols.add(record["protocol_sha256"])
    by_round = {}
    arm_counts = {}
    for kind, key, expected_rounds in (("measured", "rounds", 6), ("warmup", "warmup", 2)):
        rounds = record[key]
        assert len(rounds) == expected_rounds
        arm_counts[kind] = 0
        for row in rounds:
            assert len(row["records"]) == 8
            assert row["summary"]["failed"] == 0
            for request in row["records"]:
                assert request["success"] and request["http_status"] == 200 and request["done"]
                assert request["usage"]["prompt_tokens"] == 512
                assert request["usage"]["completion_tokens"] == 64
                assert len(request["output_token_ids"]) == 64
            arm_counts[kind] += len(row["records"])
            if kind == "measured":
                by_round[(row["repeat"], row["concurrency"])] = {
                    req["index"]: tuple(req["output_token_ids"]) for req in row["records"]
                }
        totals[kind] += arm_counts[kind]
    arms[arm] = {"requests": arm_counts, "rounds": by_round}
assert len(fixtures) == len(protocols) == 1
agreement = {}
for concurrency in (1, 8):
    pairs = []
    for repeat in (1, 2, 3):
        baseline = arms["triton-a1"]["rounds"][(repeat, concurrency)]
        changed = arms["flashinfer-b1"]["rounds"][(repeat, concurrency)]
        assert set(baseline) == set(changed)
        pairs.extend((baseline[index], changed[index]) for index in sorted(baseline))
    assert len(pairs) == 24
    agreement[str(concurrency)] = {
        "paired_requests": len(pairs),
        "identical_sequences": sum(a == b for a, b in pairs),
        "matching_token_positions": sum(x == y for a, b in pairs for x, y in zip(a, b)),
        "compared_token_positions": len(pairs) * 64,
        "distinct_sequences_by_backend": {
            arm: len({tokens for (repeat, c), rows in value["rounds"].items() if c == concurrency for tokens in rows.values()})
            for arm, value in arms.items()
        },
    }
audit = {
    "source_head": manifest["source_head"],
    "core_passed": sum(counts.values()),
    "core_counts": counts,
    "core_failures_errors_skips": 0,
    "parameter_export_probes": probes,
    "explicit_override_log": override,
    "serving": {
        "successful_retry_attempt": 2,
        "counts": totals,
        "requests_by_backend": {arm: value["requests"] for arm, value in arms.items()},
        "kv_tokens_each_backend": 21845,
        "fixture_sha256": next(iter(fixtures)),
        "protocol_sha256": next(iter(protocols)),
        "paired_output_agreement": agreement,
        "scope": "One successful launch per backend, compatibility smoke; no performance or accuracy equivalence conclusion",
    },
    "preserved_initial_pipeline_exit": (results / "pipeline.exit").read_text().strip(),
    "serving_retry_exit": (results / "serving-retry.exit").read_text().strip(),
    "limitations": ["Only SM89/L20 hardware tested", "No new benchmark or GSM8K evaluation", "Reused native binary; full CUDA13 build not validated", "Earlier environment and HV4 alignment failures retained"],
}
args.output.write_text(json.dumps(audit, indent=2) + "\n")
print(json.dumps({"core_passed": audit["core_passed"], "serving": audit["serving"]}, indent=2))
