"""Probe real inference-mode Parameters at the official FlashInfer boundary."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import importlib.metadata
import importlib.util
import inspect
import json
import os
from pathlib import Path
import sys
import traceback


def file_info(path):
    path = Path(path)
    return {
        "path": str(path),
        "resolved_path": str(path.resolve()),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def tensor_info(tensor):
    return {
        "type": type(tensor).__name__,
        "dtype": str(tensor.dtype),
        "requires_grad": tensor.requires_grad,
        "shape": list(tensor.shape),
        "stride": list(tensor.stride()),
        "storage_offset": tensor.storage_offset(),
        "pointer_alignment_mod16": tensor.data_ptr() % 16,
    }


def error_info(error):
    return {
        "type": type(error).__name__,
        "message": str(error),
        "traceback": traceback.format_exc(),
    }


def run_probe(source, result):
    sys.path.insert(0, str(source))
    import torch
    import cutlass
    import flashinfer.gdn_decode as fi_api

    runtime = importlib.import_module("cutlass.cute.runtime")
    result["runtime"] = {
        "python_executable": sys.executable,
        "torch_version": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "flashinfer_python_version": importlib.metadata.version("flashinfer-python"),
        "cute_dsl_imported_version": getattr(cutlass, "__version__", None),
        "cute_dsl_distribution_version": importlib.metadata.version(
            "nvidia-cutlass-dsl"
        ),
        "cute_runtime_enable_tvm_ffi_available": hasattr(runtime, "ENABLE_TVM_FFI"),
        "cute_runtime_enable_tvm_ffi": getattr(runtime, "ENABLE_TVM_FFI", None),
        "fi_api": file_info(fi_api.__file__),
        "cutlass": file_info(cutlass.__file__),
        "cute_runtime": file_info(runtime.__file__),
    }
    if not torch.cuda.is_available():
        raise RuntimeError("This probe requires a CUDA GPU")
    result["runtime"]["gpu"] = {
        "name": torch.cuda.get_device_name(),
        "capability": list(torch.cuda.get_device_capability()),
    }

    helper_path = (
        source / "tests/kernels/fla/test_fused_sigmoid_gating_delta_rule.py"
    )
    spec = importlib.util.spec_from_file_location("gdn_param_probe_helpers", helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    result["helper_source"] = file_info(helper_path)
    result["helper_signatures"] = {
        name: str(inspect.signature(getattr(helper, name)))
        for name in ("_decode_inputs", "_make_gdn_decode", "_assert_decode_matches")
    }
    result["adapter_source"] = file_info(
        source / "vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py"
    )

    state_dtype = torch.float32
    batch, heads, value_heads, dim = 1, 2, 4, 128
    inputs, backing = helper._decode_inputs(
        state_dtype, strided_qkv=True, batch=batch, num_v_heads=value_heads
    )
    inputs["A_log"] = torch.nn.Parameter(inputs["A_log"], requires_grad=True)
    inputs["dt_bias"] = torch.nn.Parameter(inputs["dt_bias"], requires_grad=True)
    assert inputs["A_log"].requires_grad and inputs["dt_bias"].requires_grad
    assert inputs["b"].storage_offset() == 0
    assert inputs["a"].storage_offset() == value_heads
    result["input_tensors"] = {name: tensor_info(t) for name, t in inputs.items()}
    result["shape"] = {"B": batch, "H": heads, "HV": value_heads, "K": dim, "V": dim}
    result["gate_layout"] = "b-first packed BF16 gates; a is the second half"
    indices = torch.tensor([6], device="cuda", dtype=torch.int32)
    out_raw = torch.empty(batch, 1, value_heads, dim, device="cuda", dtype=torch.bfloat16)
    out_ref = torch.empty_like(out_raw)
    out_adapter = torch.empty_like(out_raw)
    q, k, v = inputs["mixed_qkv"].split(
        (heads * dim, heads * dim, value_heads * dim), dim=-1
    )
    raw_state = None
    with torch.inference_mode():
        result["inference_mode_enabled_during_calls"] = torch.is_inference_mode_enabled()
        try:
            fi_api.gated_delta_rule_decode_pretranspose(
                q=q.view(batch, 1, heads, dim),
                k=k.view(batch, 1, heads, dim),
                v=v.view(batch, 1, value_heads, dim),
                state=None,
                A_log=inputs["A_log"],
                a=inputs["a"].unsqueeze(1),
                dt_bias=inputs["dt_bias"],
                b=inputs["b"].unsqueeze(1),
                scale=dim**-0.5,
                output=out_raw,
                use_qk_l2norm=True,
                initial_state=backing[2, :, :value_heads],
                initial_state_indices=indices,
                backend="flashinfer",
            )
            torch.cuda.synchronize()
            raw_state = backing[2].clone()
            result["raw_fi"] = {"status": "succeeded"}
        except Exception as error:
            result["raw_fi"] = {"status": "failed", "error": error_info(error)}
            message = str(error).lower()
            result["raw_fi"]["error_mentions_grad_export"] = (
                "gradient" in message or "requires_grad" in message
            )

        # The raw API attempt must not affect either comparison's initial state.
        backing[1:].copy_(backing[:1].expand_as(backing[1:]))
        result["state_reset_before_comparison"] = bool(
            torch.equal(backing[0], backing[1])
            and torch.equal(backing[0], backing[2])
        )
        reference = helper._make_gdn_decode(
            "triton", state_dtype, num_v_heads=value_heads
        )
        adapter = helper._make_gdn_decode(
            "flashinfer", state_dtype, num_v_heads=value_heads
        )
        assert reference.backend == "triton" and adapter.backend == "flashinfer"
        reference(
            **inputs,
            initial_state=backing[1, :, :value_heads],
            ssm_state_indices=indices,
            out=out_ref,
        )
        adapter(
            **inputs,
            initial_state=backing[2, :, :value_heads],
            ssm_state_indices=indices,
            out=out_adapter,
        )
        torch.cuda.synchronize()
        helper._assert_decode_matches(
            out_adapter, out_ref, backing, indices, state_dtype
        )
        result["adapter"] = {
            "status": "passed",
            "backend": adapter.backend,
            "original_helper_assertions_passed": True,
            "max_output_abs_error": (out_adapter.float() - out_ref.float())
            .abs()
            .max()
            .item(),
            "input_parameters_still_require_grad": inputs["A_log"].requires_grad
            and inputs["dt_bias"].requires_grad,
        }
        if raw_state is not None:
            raw_check = backing.clone()
            raw_check[2].copy_(raw_state)
            try:
                helper._assert_decode_matches(
                    out_raw, out_ref, raw_check, indices, state_dtype
                )
                result["raw_fi"]["matches_triton_with_original_assertions"] = True
            except Exception as error:
                result["raw_fi"]["matches_triton_with_original_assertions"] = False
                result["raw_fi"]["comparison_error"] = error_info(error)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("/source"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = {
        "purpose": "Parameter DLPack export diagnostic, not a performance benchmark",
        "script": file_info(__file__),
        "source": str(args.source.resolve()),
        "environment": {
            name: os.environ.get(name)
            for name in (
                "CUTE_DSL_ENABLE_TVM_FFI",
                "FLASHINFER_WORKSPACE_BASE",
                "FLASHINFER_CACHE_DIR",
                "FLASHINFER_JIT_DIR",
            )
        },
        "expected_runtime": {"flashinfer-python": "0.7.0.post1", "cute-dsl": "4.8.0"},
        "tolerances_modified": False,
        "installed_libraries_or_environment_modified": False,
    }
    try:
        run_probe(args.source.resolve(), result)
        result["status"] = "completed"
    except Exception as error:
        result["status"] = "failed"
        result["error"] = error_info(error)
    encoded = json.dumps(result, ensure_ascii=False, indent=2, default=str) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return int(result["status"] != "completed")


if __name__ == "__main__":
    raise SystemExit(main())
