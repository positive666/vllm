#!/usr/bin/env bash
set -u
runtime_python=/cache/gdn-runtime/bin/python
serving_exit=0
for arm in triton-a1 flashinfer-b1; do
    uv run --offline --no-project "$runtime_python" /artifacts/serve_smoke.py \
        --arm "$arm" --series final --attempt 2 --requests 8 --cache-blocks 64 \
        > /results/logs/supervisor-$arm-attempt2.log 2>&1
    arm_exit=$?
    printf '%s\n' "$arm_exit" > /results/serve-$arm-attempt2.exit
    if [ "$arm_exit" -ne 0 ]; then serving_exit=$arm_exit; fi
done
date -u '+%Y-%m-%dT%H:%M:%SZ' > /results/serving-retry.done
printf '%s\n' "$serving_exit" > /results/serving-retry.exit
exit "$serving_exit"
