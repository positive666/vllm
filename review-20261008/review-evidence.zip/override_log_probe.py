"""Check that explicit FI reports its packed-decode override once."""

import io
import json
import logging
from pathlib import Path

import torch

from tests.kernels.fla.test_fused_sigmoid_gating_delta_rule import _make_gdn_decode
from vllm import envs
from vllm.config.logging import LoggingConfig
from vllm.logger import configure_logging
from vllm.model_executor.layers.mamba.gdn.qwen_gdn_linear_attn import logger

assert not envs.VLLM_ENABLE_FLA_PACKED_RECURRENT_DECODE
configure_logging(LoggingConfig(log_level="INFO"))
stream = io.StringIO()
handler = logging.StreamHandler(stream)
logger.addHandler(handler)
try:
    for _ in range(2):
        assert _make_gdn_decode("flashinfer", torch.float32).backend == "flashinfer"
finally:
    logger.removeHandler(handler)
message = (
    "Explicit FlashInfer GDN decode overrides "
    "VLLM_ENABLE_FLA_PACKED_RECURRENT_DECODE=0 for ordinary decode"
)
assert stream.getvalue().count(message) == 1, stream.getvalue()
record = {"status": "passed", "constructions": 2, "message_count": 1, "message": message}
Path("/results/override-log-probe.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
