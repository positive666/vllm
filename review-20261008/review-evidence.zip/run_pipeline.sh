#!/usr/bin/env bash
set -u
runtime_python=/cache/gdn-runtime/bin/python
for ffi_mode in 0 1; do
    CUTE_DSL_ENABLE_TVM_FFI=$ffi_mode FLASHINFER_WORKSPACE_BASE=/cache/param-export-$ffi_mode-attempt3 \
        uv run --offline --no-project "$runtime_python" /artifacts/param_export_probe.py \
        --output /results/param-export-$ffi_mode.json \
        > /results/logs/param-export-$ffi_mode.log 2>&1
    printf '%s\n' "$?" > /results/param-export-$ffi_mode.exit
done
VLLM_ENABLE_FLA_PACKED_RECURRENT_DECODE=0 uv run --offline --no-project "$runtime_python" - \
    > /results/logs/explicit-override.log 2>&1 <<'PY'
import torch
from tests.kernels.fla.test_fused_sigmoid_gating_delta_rule import _make_gdn_decode
assert _make_gdn_decode('flashinfer', torch.float32).backend == 'flashinfer'
print('EXPLICIT_FI_OVERRIDE_CONSTRUCTION_PASSED', flush=True)
PY
printf '%s\n' "$?" > /results/explicit-override.exit
uv run --offline --no-project "$runtime_python" /artifacts/run_review.py \
    --source-head d8ae9e900e3c96a7c1b5cb53cc9f572ab0e20fd6 \
    > /results/logs/core-runner.log 2>&1
core_exit=$?
printf '%s\n' "$core_exit" > /results/core-runner.exit
if [ "$core_exit" -ne 0 ]; then
    date -u '+%Y-%m-%dT%H:%M:%SZ' > /results/pipeline.done
    exit "$core_exit"
fi
serving_exit=0
for arm in triton-a1 flashinfer-b1; do
    uv run --offline --no-project "$runtime_python" /artifacts/serve_smoke.py \
        --arm "$arm" --series final --requests 8 --cache-blocks 64 \
        > /results/logs/supervisor-$arm.log 2>&1
    arm_exit=$?
    printf '%s\n' "$arm_exit" > /results/serve-$arm.exit
    if [ "$arm_exit" -ne 0 ]; then serving_exit=$arm_exit; fi
done
date -u '+%Y-%m-%dT%H:%M:%SZ' > /results/pipeline.done
exit "$serving_exit"
