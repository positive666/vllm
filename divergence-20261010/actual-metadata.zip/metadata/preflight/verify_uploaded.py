"""Verify frozen experiment and runtime files before importing CUDA modules."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

base = Path("/results/preflight")
manifest = json.loads((base / "producer-manifest.json").read_text())
head = "d8ae9e900e3c96a7c1b5cb53cc9f572ab0e20fd6"
assert manifest["source_head"] == head
for name, expected in manifest["files"].items():
    path = Path("/short-helpers") / name
    assert path.stat().st_size == expected["bytes"] and sha(path) == expected["sha256"], name
for name, expected in manifest["host_scripts"].items():
    path = base / name
    assert path.stat().st_size == expected["bytes"] and sha(path) == expected["sha256"], name
reference = Path("/short-reference/reference")
launch = json.loads((reference / "launch.json").read_text())
binding = json.loads((reference / "runtime-binding.json").read_text())
assert binding["source_head"] == head
versions = {name: importlib.metadata.version(name) for name in launch["runtime_versions"]}
assert versions == launch["runtime_versions"]
for name, expected in binding["modules"].items():
    path = Path(expected["path"])
    assert path.stat().st_size == expected["bytes"] and sha(path) == expected["sha256"], name
for name, expected in launch["model_files"].items():
    assert sha(Path("/model") / name) == expected["sha256"], name
source = json.loads(Path("/artifacts/performance-source.json").read_text())
assert source["source_head"] == head
for name, expected in source["files"].items():
    assert sha(Path("/source") / name) == expected["sha256"], name
for name, expected in manifest["additional_source_files"].items():
    path = Path("/source") / name
    assert path.stat().st_size == expected["bytes"] and sha(path) == expected["sha256"], name
assert sha(reference / "completed.json") == manifest["reference_completed_sha256"]
assert "torch" not in sys.modules and "flashinfer" not in sys.modules
report = {"status": "PRE_GPU_FILES_EXACT", "source_head": head, "producer_manifest_sha256": sha(base / "producer-manifest.json"), "producer_files": manifest["files"], "host_scripts": manifest["host_scripts"], "runtime_versions": versions, "runtime_modules": binding["modules"], "gpu_execution": False}
with Path("/results/pre-gpu-files.json").open("x") as f:
    json.dump(report, f, indent=2)
    f.write("\n")
print(json.dumps({"status": report["status"], "files": len(manifest["files"]), "gpu_execution": False}))
