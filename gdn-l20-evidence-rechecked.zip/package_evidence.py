"""Package an explicitly audited final L20 evidence set without private ops."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path

ARMS = ("triton-a1", "flashinfer-b1", "flashinfer-b2", "triton-a2")
PRODUCTION_FILES = (
    "vllm/config/kernel.py",
    "vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py",
    "vllm/v1/attention/backends/gdn_attn.py",
)
CANONICAL_TOOLS = (
    "benchmark_gdn_takeover.py",
    "http_bench_client.py",
    "quality_http.py",
    "summarize_micro.py",
    "summarize_serving.py",
)
TOP_LEVEL_FILES = (
    "review.patch",
    "review-patch-manifest.json",
    "source-manifest.json",
    "final-micro-production.json",
    "final-micro-summary.json",
    "final-micro-results.md",
    "final-quality-results.md",
    "final-serving-results.md",
    "final-focused-tests.log",
    "final-micro.log",
    "runtime-probe.json",
    "checkpoint-bias.json",
    "gsm8k-provenance.json",
    "duplicates-final.json",
    "bf16-null-official.json",
    "baseline-overlay-manifest.json",
    "benchmark-protocol.md",
    "fi-bias-cache-review.md",
    "fi-int64-address-review.md",
    "production-review.md",
    "ci-coverage-notes.md",
    "pr-description.md",
    "pr-checklist-notes.md",
    "review-commands.md",
    "submit-preparation.md",
    "independent-recheck-20261007.md",
    "duplicate-checks-recheck.json",
    "package_evidence.py",
)
FINAL_FILES = (
    "final/http-fixture.json",
    "final/quality-triton.json",
    "final/quality-flashinfer.json",
    "final/focused-tests.exit",
    "final/micro.exit",
    "final/metadata-full.exit",
)


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def checked_path(root, relative):
    path = root / relative
    require(not path.is_symlink(), f"Refusing symlink artifact: {relative}")
    require(path.resolve().is_relative_to(root), f"Path escapes root: {relative}")
    require(path.is_file(), f"Required final artifact missing: {relative}")
    return path


def check_pytest_summary(path, expected_passed):
    text = path.read_text(encoding="utf-8")
    rows = [line for line in text.splitlines() if re.match(r"^=+\s", line)]
    require(bool(rows), f"No pytest summary found: {path.name}")
    counts = dict(
        (name, int(count))
        for count, name in re.findall(
            r"\b(\d+) (passed|failed|errors?|skipped|xfailed|xpassed)\b", rows[-1]
        )
    )
    require(
        counts.get("passed") == expected_passed, f"Passed count differs: {path.name}"
    )
    require(
        all(count == 0 for name, count in counts.items() if name != "passed"),
        f"Non-passing tests are present: {path.name}",
    )


def validate(root, summary_path):
    require(summary_path.resolve().is_relative_to(root), "Summary must be in root")
    summary = load(summary_path)
    for key in ("complete", "server_evidence_audited", "kv_capacity_matched"):
        require(summary.get(key) is True, f"Final summary has not passed {key}")
    require(summary["series"] == "final", "Preliminary summary cannot be packaged")
    require(summary["measured_requests"] == 768, "Final measured count differs")
    require(summary["warmup_requests"] == 64, "Final warmup count differs")
    require(summary["http_failures"] == 0, "Final HTTP failures are present")
    require(summary["quality"]["complete"], "Matched quality is incomplete")
    require(summary["quality"]["matched_questions"] == 100, "Quality count differs")
    require(summary["quality"]["protocol"]["max_tokens"] == 1750, "Budget differs")
    require(
        summary["parser_sha256"] == sha256(root / "summarize_serving.py"),
        "Summary was produced by a different parser revision",
    )

    source_manifest = load(root / "source-manifest.json")
    review_manifest = load(root / "review-patch-manifest.json")
    require(
        sha256(root / "source-manifest.json") == summary["source_manifest_sha256"],
        "Source manifest changed since serving audit",
    )
    require(review_manifest["files"] == source_manifest["files"], "Patch files differ")
    require(len(review_manifest["files"]) == 8, "Review patch must cover eight files")
    require(
        review_manifest["base_commit"] == source_manifest["base"],
        "Patch and source have different bases",
    )
    require(
        sha256(root / "review.patch") == review_manifest["patch_sha256"],
        "Review patch changed since its manifest",
    )
    patch_text = (root / "review.patch").read_text(encoding="utf-8")
    paths = re.findall(r"^diff --git a/(.*?) b/(.*?)$", patch_text, re.MULTILINE)
    require(all(left == right for left, right in paths), "Unexpected rename in patch")
    require(
        len(paths) == 8
        and {left for left, _ in paths} == set(source_manifest["files"]),
        "Patch diff paths do not match the eight-file manifest",
    )

    micro_path = root / "final-micro-production.json"
    micro = load(micro_path)
    micro_summary = load(root / "final-micro-summary.json")
    require(micro["all_correctness_passed"], "Final micro correctness did not pass")
    require(
        len(micro["cases"]) == 10 and micro["args"]["steps"] == 128, "Matrix differs"
    )
    require(
        micro_summary["input_sha256"] == sha256(micro_path), "Micro summary is stale"
    )
    require(
        micro["source_file_sha256"] == source_manifest["files"][PRODUCTION_FILES[1]],
        "Final micro source differs from reviewed source",
    )
    require(
        micro_summary["source_sha256"] == micro["source_file_sha256"]
        and micro_summary["harness_sha256"] == micro["harness_sha256"],
        "Micro summary provenance differs",
    )
    require(
        micro["harness_sha256"] == sha256(root / "benchmark_gdn_takeover.py"),
        "Final micro harness differs from canonical tool",
    )
    for case in micro["cases"]:
        checks = case["correctness"]
        require(case["passed"], "Failed micro case is present")
        require(
            checks["inactive_slots_bitwise_unchanged"], "Inactive state was modified"
        )
        require(
            checks["cache_page_padding_bitwise_unchanged"], "Page padding was modified"
        )
        for metrics in checks["trajectory"].values():
            require(metrics["pointwise_over_threshold"] == 0, "Numerical gate violated")
            require(metrics["relative_l2"] < 0.01, "Relative-L2 gate violated")

    for arm in ARMS:
        raw_path = root / "final" / "http" / f"{arm}.json"
        raw = load(raw_path)
        audit = summary["launches"][arm]
        finished_path = root / "final" / f"serve-final-{arm}.json"
        log_path = root / "final" / "logs" / f"serve-final-{arm}.log"
        finished = load(finished_path)
        require(
            raw["arm"] == finished["arm"] == arm,
            f"Canonical filename contains a different arm: {arm}",
        )
        require(finished["backend"] == arm.split("-")[0], f"Backend differs: {arm}")
        require(raw["all_successful"], f"HTTP failures for {arm}")
        require(audit["input_sha256"] == sha256(raw_path), f"Stale HTTP audit: {arm}")
        require(
            audit["completed_evidence"]["sha256"] == sha256(finished_path),
            f"Stale finished evidence audit: {arm}",
        )
        require(finished["status"] == "completed", f"Incomplete launch: {arm}")
        require(
            audit["log_evidence"]["sha256"]
            == finished["server_log_sha256"]
            == sha256(log_path),
            f"Stale server log audit: {arm}",
        )
        require(
            raw["client_sha256"] == sha256(root / "http_bench_client.py"),
            f"HTTP client revision differs: {arm}",
        )
        expected = {name: source_manifest["files"][name] for name in PRODUCTION_FILES}
        require(
            finished["source_files"] == expected, f"Production source differs: {arm}"
        )
        require(
            raw["server_evidence"]["runtime"]["torch"] == micro["packages"]["torch"],
            f"Micro and serving Torch runtimes differ: {arm}",
        )
    for backend in ("triton", "flashinfer"):
        path = root / "final" / f"quality-{backend}.json"
        quality = load(path)
        require(
            summary["quality"]["arms"][backend]["input_sha256"] == sha256(path),
            f"Quality audit is stale: {backend}",
        )
        require(
            quality["harness_sha256"] == sha256(root / "quality_http.py"),
            f"Quality client revision differs: {backend}",
        )
        require(
            "completed_and_correct" in summary["quality"]["arms"][backend]["summary"],
            "Conservative quality counts are missing",
        )
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).parent)
    parser.add_argument("--summary", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--metadata-log", type=Path)
    parser.add_argument("--config-log", type=Path)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    summary_path = (args.summary or root / "final/serving-summary.json").resolve()
    summary = validate(root, summary_path)
    names = list(TOP_LEVEL_FILES + CANONICAL_TOOLS + FINAL_FILES)
    names.append(summary_path.relative_to(root).as_posix())
    metadata_log = args.metadata_log or root / "metadata-tests-full-final.log"
    config_log = args.config_log or root / "config-tests-final.log"
    for path in (metadata_log, config_log):
        require(path.resolve().is_relative_to(root), "Test log must be in root")
        names.append(path.resolve().relative_to(root).as_posix())
    for arm in ARMS:
        names.extend(
            (
                f"final/http/{arm}.json",
                f"final/serve-final-{arm}.json",
                f"final/logs/serve-final-{arm}.log",
                f"final/{arm}.exit",
            )
        )
    names = sorted(set(names))
    paths = {name: checked_path(root, name) for name in names}
    for name, path in paths.items():
        if name.endswith(".exit"):
            require(path.read_text().strip() == "0", f"Stage failed: {name}")
    check_pytest_summary(paths["final-focused-tests.log"], 31)
    check_pytest_summary(metadata_log, 63)
    check_pytest_summary(config_log, 1)
    for name in ("final-quality-results.md", "final-serving-results.md"):
        require(
            "serving-partial" not in paths[name].read_text(encoding="utf-8"),
            f"Canonical report still references partial evidence: {name}",
        )
    paths.update(
        {
            "diagnostics/mtp-patch-before-final-bias-fix.log": checked_path(
                root, "mixed-mtp-final.log"
            ),
            "diagnostics/mtp-unchanged-baseline.log": checked_path(
                root, "mtp-baseline.log"
            ),
        }
    )
    manifest = {
        "scope": "Final eight-file patch and audited L20 evidence; AI assistance used",
        "source_manifest_sha256": summary["source_manifest_sha256"],
        "serving_summary_sha256": sha256(summary_path),
        "measured_requests": 768,
        "warmup_requests": 64,
        "kv_capacity_tokens": summary["kv_capacity_tokens"],
        "files": {
            name: {"sha256": sha256(path), "bytes": path.stat().st_size}
            for name, path in paths.items()
        },
    }
    if args.check_only:
        print(json.dumps({"validated": True, "files": len(paths)}))
        return
    output = (args.output or root / "gdn-l20-evidence-final.zip").resolve()
    require(not output.exists(), f"Refusing to overwrite {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    readme = (
        "# Final FlashInfer GDN L20 evidence\n\n"
        "Start with final-serving-results.md, final-micro-results.md "
        "and review.patch.\n"
        "evidence-manifest.json records every included file's SHA256.\n"
        "Serving uses four independent ABBA launches and the same 100-question\n"
        "GSM8K subset. Raw parsed and conservative completed-answer scores are\n"
        "reported separately. No accuracy-equivalence claim is made.\n\n"
        "The native extension is reused from the identified CUDA12.9 wheel.\n"
        "Existing MTP failures were reproduced on baseline and the patch before\n"
        "the final bias fix; they are distinctly labeled diagnostic logs.\n"
        "This is not new passing MTP coverage.\n\n"
        "Only explicitly whitelisted final evidence and decision diagnostics\n"
        "are included. Private remote operations, credentials, source archives\n"
        "and preliminary serving/microbenchmark data are excluded.\n"
    )
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, path in paths.items():
            archive.write(path, name)
        archive.writestr("evidence-manifest.json", json.dumps(manifest, indent=2))
        archive.writestr("README.md", readme)
    print(
        json.dumps(
            {
                "output": str(output),
                "sha256": sha256(output),
                "bytes": output.stat().st_size,
                "files": len(paths) + 2,
            }
        )
    )


if __name__ == "__main__":
    main()
