"""Audit and summarize independent ABBA serving launches and matched quality.

Descriptive comparisons use two launches per backend. They never treat hundreds
of requests from the same process as independent experiments or claim accuracy
equivalence from the deterministic 100-question screen.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import statistics
from pathlib import Path

from http_bench_client import digest, percentile
from quality_http import answer_number

ARMS = ("triton-a1", "flashinfer-b1", "flashinfer-b2", "triton-a2")
PAIRS = (("triton-a1", "flashinfer-b1"), ("triton-a2", "flashinfer-b2"))
METRICS = (
    "throughput_tps",
    "ttft_mean_ms",
    "ttft_p50_ms",
    "tpot_mean_ms",
    "tpot_p50_ms",
)
PRODUCTION_FILES = (
    "vllm/config/kernel.py",
    "vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py",
    "vllm/v1/attention/backends/gdn_attn.py",
)


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(actual, expected):
    assert math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-10), (
        actual,
        expected,
    )


def normalize_command(command, expected_backend):
    result = list(command)
    index = result.index("--kernel-config") + 1
    config = json.loads(result[index])
    assert config.pop("gdn_decode_backend") == expected_backend
    assert config["linear_backend"] == "marlin"
    result[index] = json.dumps(config, sort_keys=True)
    if "--attention-config" in result:
        index = result.index("--attention-config") + 1
        result[index] = json.dumps(json.loads(result[index]), sort_keys=True)
    assert result[result.index("--mamba-ssm-cache-dtype") + 1] == "float32"
    assert result[result.index("--dtype") + 1] == "bfloat16"
    assert result[result.index("--seed") + 1] == "42"
    assert "--no-enable-prefix-caching" in result
    return result


def check_round(round_, input_hash, protocol_hash):
    assert round_["input_tokens_sha256"] == input_hash
    assert round_["protocol_sha256"] == protocol_hash
    records = round_["records"]
    assert len(records) == round_["requests_target"]
    assert sorted(row["index"] for row in records) == list(range(len(records)))
    for row in records:
        assert row["success"] and row["done"] and row["http_status"] == 200
        assert row["usage"]["prompt_tokens"] == 512
        assert row["usage"]["completion_tokens"] == len(row["output_token_ids"]) == 64
        assert row["finish_reason"] == "length"
        assert len(row["prompt_token_ids"]) == 512
        assert digest(row["prompt_token_ids"]) == input_hash
        assert digest(row["output_token_ids"]) == row["output_token_ids_sha256"]
        assert hashlib.sha256(row["text"].encode()).hexdigest() == row["text_sha256"]
        assert row["text"]
        text_times = [chunk["received_after_send_seconds"] for chunk in row["chunks"]]
        token_times = [
            chunk["received_after_send_seconds"] for chunk in row["token_chunks"]
        ]
        assert text_times == sorted(text_times) and token_times == sorted(token_times)
        assert sum(chunk["token_count"] for chunk in row["token_chunks"]) == 64
        assert 0 <= token_times[0] <= token_times[-1] <= row["request_seconds"]
        close(row["ttft_ms"], text_times[0] * 1000)
        close(row["token_ttft_ms"], token_times[0] * 1000)
        close(row["tpot_ms"], (token_times[-1] - token_times[0]) / 63 * 1000)
        close(
            row["request_seconds"],
            row["ended_after_round_seconds"] - row["started_after_round_seconds"],
        )
    summary = round_["summary"]
    assert summary["requests"] == summary["successful"] == len(records)
    assert summary["failed"] == 0
    assert summary["output_tokens"] == 64 * len(records)
    assert summary["wall_seconds"] >= max(
        row["ended_after_round_seconds"] for row in records
    )
    close(
        summary["output_tokens_per_second"], 64 * len(records) / summary["wall_seconds"]
    )
    for metric in ("ttft_ms", "tpot_ms"):
        values = [row[metric] for row in records]
        close(summary[metric]["mean"], statistics.mean(values))
        close(summary[metric]["p50"], percentile(values, 0.5))
    return {
        "throughput_tps": summary["output_tokens_per_second"],
        "ttft_mean_ms": summary["ttft_ms"]["mean"],
        "ttft_p50_ms": summary["ttft_ms"]["p50"],
        "tpot_mean_ms": summary["tpot_ms"]["mean"],
        "tpot_p50_ms": summary["tpot_ms"]["p50"],
    }


def launch_name(evidence, series):
    arm = evidence["arm"]
    launch = arm if evidence["attempt"] == 1 else f"{arm}-attempt{evidence['attempt']}"
    return f"{series}-{launch}" if series == "final" else launch


def log_evidence(evidence, logs_dir, series):
    path = logs_dir / f"serve-{launch_name(evidence, series)}.log"
    result = {"path": str(path), "available": path.exists()}
    if not path.exists():
        result["kv_capacity"] = "not observed in available artifacts"
        return result
    text = re.sub(
        r"\x1b\[[0-9;]*m", "", path.read_text(encoding="utf-8", errors="replace")
    )
    result["sha256"] = sha256(path)
    result["capacity_and_backend_lines"] = [
        line
        for line in text.splitlines()
        if any(
            marker in line
            for marker in (
                "GPU KV cache size:",
                "Maximum concurrency for",
                "Available KV cache memory:",
                "GDN non-speculative decode backend:",
            )
        )
    ]
    match = re.search(r"GPU KV cache size:\s*([\d,]+)\s*tokens", text)
    result["kv_capacity_tokens"] = int(match[1].replace(",", "")) if match else None
    return result


def completed_evidence(ready, evidence_dir, log, series, sources, allow_partial):
    path = evidence_dir / f"serve-{launch_name(ready, series)}.json"
    result = {"path": str(path), "available": path.exists(), "audited": False}
    if not path.exists():
        if not allow_partial:
            raise FileNotFoundError(path)
        return result
    finished = load(path)
    assert finished["status"] != "failed", (path, finished.get("error"))
    assert ready["status"] == "ready"
    for key, value in ready.items():
        if key != "status":
            assert finished[key] == value, (path, key)
    if series == "final":
        assert set(finished["source_files"]) == set(PRODUCTION_FILES)
        assert finished["source_files"] == sources, "Final production source differs"
        command = finished["command"]
        assert command[command.index("--num-gpu-blocks-override") + 1] == "64"
    result.update(
        sha256=sha256(path),
        status=finished["status"],
        ready_snapshot_matches=True,
        source_files=finished.get("source_files"),
    )
    if finished["status"] != "completed":
        assert allow_partial, (path, finished["status"])
        return result
    result.update(
        server_exit=finished["server_exit"],
        finished_utc=finished["finished_utc"],
        server_log_sha256=finished["server_log_sha256"],
    )
    assert ready["started_utc"] <= ready["ready_utc"] <= finished["finished_utc"]
    if not log["available"]:
        if not allow_partial:
            raise FileNotFoundError(log["path"])
        return result
    assert log["sha256"] == finished["server_log_sha256"], "Finished log hash differs"
    assert log["kv_capacity_tokens"] is not None, "KV capacity absent from startup log"
    assert any(
        f"GDN non-speculative decode backend: {ready['backend']}" in line
        for line in log["capacity_and_backend_lines"]
    ), "Requested backend was not observed in startup log"
    result["audited"] = True
    return result


def launch_summary(path, logs_dir, evidence_dir, series, sources, allow_partial):
    report = load(path)
    arm = report["arm"]
    assert arm in ARMS and report["all_successful"]
    assert digest(report["protocol"]) == report["protocol_sha256"]
    assert len(report["warmup"]) == 2 and len(report["rounds"]) == 6
    assert sorted(row["concurrency"] for row in report["warmup"]) == [1, 8]
    assert all(row["requests_target"] == 8 for row in report["warmup"])
    assert all(
        row["requests_target"] == report["requests_per_round"]
        for row in report["rounds"]
    )
    assert [(row["repeat"], row["concurrency"]) for row in report["rounds"]] == [
        (1, 1),
        (1, 8),
        (2, 8),
        (2, 1),
        (3, 1),
        (3, 8),
    ]
    evidence = report["server_evidence"]
    assert evidence["arm"] == arm and evidence["backend"] == arm.split("-")[0]
    assert evidence["runtime"]["gpu_count"] == 1
    common_command = normalize_command(evidence["command"], evidence["backend"])
    logs = log_evidence(evidence, logs_dir, series)
    finished = completed_evidence(
        evidence, evidence_dir, logs, series, sources, allow_partial
    )
    if series == "final":
        assert evidence["source_files"] == sources, "Embedded production source differs"
    result = {
        "input_file": str(path),
        "input_sha256": sha256(path),
        "backend": evidence["backend"],
        "server_pid": evidence["server_pid"],
        "started_utc": evidence["started_utc"],
        "normalized_command_sha256": digest(common_command),
        "normalized_command": common_command,
        "runtime_sha256": digest(evidence["runtime"]),
        "runtime": evidence["runtime"],
        "measured_requests": 0,
        "warmup_requests": 0,
        "http_failures": 0,
        "concurrency": {},
        "source_files": evidence.get("source_files"),
        "log_evidence": logs,
        "completed_evidence": finished,
    }
    for row in report["warmup"]:
        assert row["kind"] == "warmup" and row["repeat"] == 0
        check_round(row, report["input_tokens_sha256"], report["protocol_sha256"])
        result["warmup_requests"] += len(row["records"])
    for concurrency in (1, 8):
        rounds = [row for row in report["rounds"] if row["concurrency"] == concurrency]
        values = [
            check_round(row, report["input_tokens_sha256"], report["protocol_sha256"])
            for row in rounds
        ]
        result["concurrency"][concurrency] = {
            "requests": sum(len(row["records"]) for row in rounds),
            "rounds": values,
            "median_of_three_rounds": {
                metric: statistics.median(row[metric] for row in values)
                for metric in METRICS
            },
            "round_minmax": {
                metric: [
                    min(row[metric] for row in values),
                    max(row[metric] for row in values),
                ]
                for metric in METRICS
            },
            "unique_output_token_sequences": len(
                {
                    row["output_token_ids_sha256"]
                    for round_ in rounds
                    for row in round_["records"]
                }
            ),
        }
        result["measured_requests"] += result["concurrency"][concurrency]["requests"]
    return report, result


def serving_comparison(raw, launches):
    result = {"backend_launches": {}, "paired_ABBA": {}}
    for concurrency in (1, 8):
        result["backend_launches"][concurrency] = {}
        for backend in ("triton", "flashinfer"):
            selected = [
                row["concurrency"][concurrency]["median_of_three_rounds"]
                for row in launches.values()
                if row["backend"] == backend
            ]
            result["backend_launches"][concurrency][backend] = {
                "independent_launches": len(selected),
                "metrics": {
                    metric: {
                        "median_across_launches": statistics.median(
                            row[metric] for row in selected
                        ),
                        "launch_minmax": [
                            min(row[metric] for row in selected),
                            max(row[metric] for row in selected),
                        ],
                        "launch_values": [row[metric] for row in selected],
                    }
                    for metric in METRICS
                },
            }
        pairs = []
        for baseline_arm, candidate_arm in PAIRS:
            if baseline_arm not in launches or candidate_arm not in launches:
                continue
            baseline = launches[baseline_arm]["concurrency"][concurrency][
                "median_of_three_rounds"
            ]
            candidate = launches[candidate_arm]["concurrency"][concurrency][
                "median_of_three_rounds"
            ]
            effects = {
                metric: 100 * (candidate[metric] / baseline[metric] - 1)
                if metric == "throughput_tps"
                else 100 * (1 - candidate[metric] / baseline[metric])
                for metric in METRICS
            }
            a_records = [
                record
                for row in raw[baseline_arm]["rounds"]
                if row["concurrency"] == concurrency
                for record in sorted(row["records"], key=lambda record: record["index"])
            ]
            b_records = [
                record
                for row in raw[candidate_arm]["rounds"]
                if row["concurrency"] == concurrency
                for record in sorted(row["records"], key=lambda record: record["index"])
            ]
            assert len(a_records) == len(b_records)
            pairs.append(
                {
                    "baseline": baseline_arm,
                    "candidate": candidate_arm,
                    "effect_percent": effects,
                    "effect_sign": (
                        "positive means increased throughput or reduced latency"
                    ),
                    "paired_requests": len(a_records),
                    "paired_exact_token_sequences": sum(
                        a["output_token_ids"] == b["output_token_ids"]
                        for a, b in zip(a_records, b_records)
                    ),
                }
            )
        result["paired_ABBA"][concurrency] = {
            "pairs": pairs,
            "median_effect_percent": {
                metric: statistics.median(
                    pair["effect_percent"][metric] for pair in pairs
                )
                for metric in METRICS
            }
            if pairs
            else None,
            "limitation": (
                "descriptive independent launch counts: "
                + str(
                    {
                        backend: sum(
                            row["backend"] == backend for row in launches.values()
                        )
                        for backend in ("triton", "flashinfer")
                    }
                )
                + "; final design is two launches per backend; "
                "no confidence interval or significance claim"
            ),
        }
    return result


def quality_summary(report):
    examples = report["examples"]
    assert len({row["index"] for row in examples}) == len(examples)
    for row in examples:
        assert digest(row["token_ids"]) == row["token_ids_sha256"]
        assert len(row["token_ids"]) == row["usage"]["completion_tokens"]
        assert answer_number(row["text"]) == row["predicted"]
        assert row["correct"] == (row["predicted"] == row["gold"])
        assert row["truncated"] == (row["finish_reason"] == "length")
        assert row["has_answer_marker"] == ("####" in row["text"])
    summary = {
        "samples": len(examples),
        "correct": sum(row["correct"] for row in examples),
        "truncated": sum(row["truncated"] for row in examples),
        "unparsed": sum(row["predicted"] is None for row in examples),
        "missing_answer_marker": sum(not row["has_answer_marker"] for row in examples),
        "http_failures": 0,
    }
    assert summary == report["summary"]
    summary.update(
        completed_and_correct=sum(
            row["correct"] and not row["truncated"] for row in examples
        ),
        final_marker_and_untruncated_correct=sum(
            row["correct"] and row["has_answer_marker"] and not row["truncated"]
            for row in examples
        ),
        truncated_and_correct=sum(
            row["correct"] and row["truncated"] for row in examples
        ),
    )
    return summary


def quality_comparison(results_dir, allow_partial, series, serving_raw):
    paths = {
        backend: results_dir / f"quality-{backend}.json"
        for backend in ("triton", "flashinfer")
    }
    reports = {backend: load(path) for backend, path in paths.items() if path.exists()}
    for backend, report in reports.items():
        if series == "final":
            assert report["arm"] == backend
            assert report["fixture"]["samples"] == 100
            assert report["protocol"]["max_tokens"] == 1750
            arm = "triton-a1" if backend == "triton" else "flashinfer-b1"
            if arm in serving_raw:
                assert report["server_evidence"] == serving_raw[arm]["server_evidence"]
            else:
                assert allow_partial, "Quality launch has no matched serving evidence"
    if len(reports) < 2 and not allow_partial:
        raise FileNotFoundError("Both quality result files are required")
    result = {
        "complete": len(reports) == 2,
        "arms": {
            backend: {
                "input_sha256": sha256(paths[backend]),
                "summary": quality_summary(report),
                "truncated_examples": [
                    {
                        key: row[key]
                        for key in (
                            "index",
                            "gold",
                            "predicted",
                            "correct",
                            "finish_reason",
                            "has_answer_marker",
                            "token_ids_sha256",
                        )
                    }
                    | {
                        "output_tokens": len(row["token_ids"]),
                        "text_tail": row["text"][-250:],
                    }
                    for row in report["examples"]
                    if row["truncated"]
                ],
            }
            for backend, report in reports.items()
        },
        "limitation": (
            "100-question deterministic zero-shot subset is a quality screen, "
            "not statistical accuracy equivalence; raw final-number fallback "
            "may credit unfinished outputs, so completed-and-correct and "
            "final-marker-and-untruncated-correct counts are separate"
        ),
    }
    if len(reports) < 2:
        return result
    baseline, candidate = reports["triton"], reports["flashinfer"]
    for key in (
        "fixture",
        "question_fixture_sha256",
        "protocol",
        "model",
        "harness_sha256",
    ):
        assert baseline[key] == candidate[key], key
    assert baseline["fixture"]["samples"] == 100
    assert baseline["fixture"]["selection_seed"] == 42
    assert baseline["fixture"]["kind"] == "gsm8k_test_zero_shot"
    assert (
        baseline["protocol"]["temperature"] == 0 and baseline["protocol"]["seed"] == 42
    )
    assert baseline["protocol"]["enable_thinking"] is False
    a_rows = {row["index"]: row for row in baseline["examples"]}
    b_rows = {row["index"]: row for row in candidate["examples"]}
    assert a_rows.keys() == b_rows.keys()
    fixture = [
        {key: row[key] for key in ("index", "question", "gold", "gold_text")}
        for row in baseline["examples"]
    ]
    assert digest(fixture) == baseline["question_fixture_sha256"]
    result.update(
        fixture=baseline["fixture"],
        question_fixture_sha256=baseline["question_fixture_sha256"],
        quality_client_sha256=baseline["harness_sha256"],
        protocol=baseline["protocol"],
        matched_questions=len(a_rows),
        exact_token_sequences=0,
        predicted_answers_changed=0,
        correctness_flips=0,
        completed_correctness_flips=0,
        final_marker_and_untruncated_correctness_flips=0,
        triton_completed_correct_flashinfer_not=0,
        triton_not_completed_correct_flashinfer=0,
        triton_correct_flashinfer_incorrect=0,
        triton_incorrect_flashinfer_correct=0,
        truncation_union=0,
        truncation_intersection=0,
        all_truncated_question_outcomes=[],
        changed_examples=[],
    )
    for index in sorted(a_rows):
        a, b = a_rows[index], b_rows[index]
        for key in ("question", "gold", "gold_text", "prompt"):
            assert a[key] == b[key], (index, key)
        same_tokens = a["token_ids"] == b["token_ids"]
        result["exact_token_sequences"] += same_tokens
        result["predicted_answers_changed"] += a["predicted"] != b["predicted"]
        result["correctness_flips"] += a["correct"] != b["correct"]
        a_completed = a["correct"] and not a["truncated"]
        b_completed = b["correct"] and not b["truncated"]
        result["completed_correctness_flips"] += a_completed != b_completed
        result["final_marker_and_untruncated_correctness_flips"] += (
            a_completed and a["has_answer_marker"]
        ) != (b_completed and b["has_answer_marker"])
        result["triton_completed_correct_flashinfer_not"] += (
            a_completed and not b_completed
        )
        result["triton_not_completed_correct_flashinfer"] += (
            not a_completed and b_completed
        )
        result["triton_correct_flashinfer_incorrect"] += (
            a["correct"] and not b["correct"]
        )
        result["triton_incorrect_flashinfer_correct"] += (
            not a["correct"] and b["correct"]
        )
        result["truncation_union"] += a["truncated"] or b["truncated"]
        result["truncation_intersection"] += a["truncated"] and b["truncated"]
        if a["truncated"] or b["truncated"]:
            result["all_truncated_question_outcomes"].append(
                {
                    "index": index,
                    "gold": a["gold"],
                    "exact_token_sequence": same_tokens,
                    "triton": {
                        key: a[key]
                        for key in (
                            "predicted",
                            "correct",
                            "truncated",
                            "has_answer_marker",
                        )
                    },
                    "flashinfer": {
                        key: b[key]
                        for key in (
                            "predicted",
                            "correct",
                            "truncated",
                            "has_answer_marker",
                        )
                    },
                }
            )
        if not same_tokens and len(result["changed_examples"]) < 8:
            first = next(
                (
                    position
                    for position, (left, right) in enumerate(
                        zip(a["token_ids"], b["token_ids"])
                    )
                    if left != right
                ),
                min(len(a["token_ids"]), len(b["token_ids"])),
            )
            first_text = next(
                (
                    position
                    for position, (left, right) in enumerate(zip(a["text"], b["text"]))
                    if left != right
                ),
                min(len(a["text"]), len(b["text"])),
            )
            result["changed_examples"].append(
                {
                    "index": index,
                    "gold": a["gold"],
                    "first_divergent_token_index": first,
                    "triton_token_context": a["token_ids"][
                        max(0, first - 4) : first + 5
                    ],
                    "flashinfer_token_context": b["token_ids"][
                        max(0, first - 4) : first + 5
                    ],
                    "triton_text_context": a["text"][
                        max(0, first_text - 60) : first_text + 160
                    ],
                    "flashinfer_text_context": b["text"][
                        max(0, first_text - 60) : first_text + 160
                    ],
                    "triton_predicted": a["predicted"],
                    "flashinfer_predicted": b["predicted"],
                    "triton_truncated": a["truncated"],
                    "flashinfer_truncated": b["truncated"],
                }
            )
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", type=Path, default=Path(__file__).parent)
    parser.add_argument("--logs-dir", type=Path)
    parser.add_argument("--evidence-dir", type=Path)
    parser.add_argument("--quality-dir", type=Path)
    parser.add_argument("--series", choices=("final", "preliminary"), default="final")
    parser.add_argument(
        "--source-manifest",
        type=Path,
        default=Path(__file__).parent / "source-manifest.json",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--allow-partial", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    sources = None
    if args.series == "final":
        manifest = load(args.source_manifest)
        sources = {name: manifest["files"][name] for name in PRODUCTION_FILES}
    evidence_dir = args.evidence_dir or (
        args.results_dir.parent if args.results_dir.name == "http" else args.results_dir
    )
    raw, launches = {}, {}
    shared = None
    for arm in ARMS:
        alternatives = [
            args.results_dir / f"http-{arm}.json",
            args.results_dir / f"{arm}.json",
        ]
        existing = [path for path in alternatives if path.exists()]
        if len(existing) == 2:
            assert sha256(existing[0]) == sha256(existing[1]), (
                "Conflicting prefixed/bare input files",
                arm,
            )
        path = existing[0] if existing else alternatives[0]
        if not path.exists():
            if args.allow_partial:
                continue
            raise FileNotFoundError(path)
        raw[arm], launches[arm] = launch_summary(
            path,
            args.logs_dir or args.results_dir,
            evidence_dir,
            args.series,
            sources,
            args.allow_partial,
        )
        report = raw[arm]
        assert report["arm"] == arm, "Canonical filename contains a different arm"
        comparable = {
            key: report[key]
            for key in (
                "protocol",
                "protocol_sha256",
                "input_tokens_sha256",
                "fixture_sha256",
                "client_sha256",
                "model",
                "requests_per_round",
            )
        }
        comparable.update(
            command=launches[arm]["normalized_command"],
            runtime=launches[arm]["runtime"],
            source_files=launches[arm]["source_files"],
        )
        if shared is None:
            shared = comparable
        else:
            assert comparable == shared, (
                f"Configuration/workload/runtime differs for {arm}"
            )
    starts = [row["started_utc"] for row in launches.values()]
    assert all(before < after for before, after in zip(starts, starts[1:])), (
        "Completed launches do not follow strict ABBA order"
    )
    identities = {(row["server_pid"], row["started_utc"]) for row in launches.values()}
    assert len(identities) == len(launches), "Repeated independent launch identity"
    result = {
        "complete": len(launches) == 4,
        "parser_sha256": sha256(Path(__file__)),
        "series": args.series,
        "server_evidence_audited": len(launches) == 4
        and all(row["completed_evidence"]["audited"] for row in launches.values()),
        "source_manifest_sha256": (
            sha256(args.source_manifest) if args.series == "final" else None
        ),
        "shared_configuration_sha256": digest(shared),
        "launches": launches,
        "measured_requests": sum(row["measured_requests"] for row in launches.values()),
        "warmup_requests": sum(row["warmup_requests"] for row in launches.values()),
        "http_failures": sum(row["http_failures"] for row in launches.values()),
        "quality": quality_comparison(
            args.quality_dir or args.results_dir,
            args.allow_partial,
            args.series,
            raw,
        ),
        "limits": [
            "Same command/runtime verified except GDN backend; fresh cache paths "
            "configured by supervisor, not independently observed in result files",
            "Actual KV capacity is matched only when all four completed "
            "launch logs and their recorded hashes have been audited",
            "TPOT is based on first/last token-ID chunks, not individual-token ITL",
            "Two independent launches per backend, three timed rounds each; "
            "no confidence/significance claim",
            "Serving uses precompiled native reuse and current-main Python overlay; "
            "no native-current-main build claim",
            "Existing MTP suite: 7 pass, 7 skip, 2 failures reproduced on baseline; "
            "native fused operator absent in reused CUDA12.9 runtime "
            "(current build is CUDA13-gated), not new passing coverage",
        ],
    }
    if result["complete"]:
        requests_per_round = shared["requests_per_round"]
        assert requests_per_round == 32
        result["requests_per_round"] = requests_per_round
        result["expected_measured_requests"] = 4 * 2 * 3 * requests_per_round
        assert result["measured_requests"] == result["expected_measured_requests"]
        assert result["warmup_requests"] == 64
    if result["server_evidence_audited"]:
        capacities = {
            row["log_evidence"]["kv_capacity_tokens"] for row in launches.values()
        }
        if args.series == "final":
            assert len(capacities) == 1, "Final observed KV capacities differ"
        result["kv_capacity_matched"] = len(capacities) == 1
        result["kv_capacity_tokens"] = sorted(capacities)
    else:
        result["kv_capacity_matched"] = False
        result["kv_capacity_tokens"] = None
    if launches:
        # Partial summaries remain useful while the four launches finish.
        backend_present = {row["backend"] for row in launches.values()}
        if backend_present == {"triton", "flashinfer"}:
            result["comparison"] = serving_comparison(raw, launches)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
    print(
        json.dumps(
            {
                "output": str(args.output),
                "complete": result["complete"],
                "server_evidence_audited": result["server_evidence_audited"],
                "kv_capacity_matched": result["kv_capacity_matched"],
                "measured_requests": result["measured_requests"],
                "warmup_requests": result["warmup_requests"],
                "http_failures": result["http_failures"],
                "quality_complete": result["quality"]["complete"],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
