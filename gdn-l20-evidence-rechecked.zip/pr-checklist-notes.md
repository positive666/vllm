# New FlashInfer GDN continuation: review preparation

Final-source tests, microbenchmarks, four-launch serving and the 100-question
quality screen are complete. Submission awaits public evidence links and human
review. Native-current-main, pinned CuTeDSL 4.8 and H20 coverage remain untested.
This note follows the current main `/pr-checklist` skill.

1. Design fit: medium-complexity change across configuration, the existing
   Qwen GDN layer, and its metadata
   builder. Reuses the current mixed split and CustomOp pattern; no scheduler,
   cache-manager or model-runner rewrite. MRV2 calls the same metadata
   build/capture/group-update paths. Only explicit FI adds index buffers.
2. Testing: existing suites cover FP32 indexed/page-strided pools, both index
   dtypes, packed projection strides, null/unused slots, graph replay, mixed
   batches, real bias loading, MTP and cache-key separation. Adapter: 19 passed;
   full metadata: 63 passed (including four FI cases); mixed/config: 12/1 passed;
   95 targeted tests passed in total. FP32 reference
   plus 128-step trajectories: all 10 cases passed. MTP: 7 passed, 7 skipped,
   2 failed because the reused native runtime lacks the fused post-convolution
   op; unchanged-main baseline reproduces both failures and the same counts.
   Final three-round micro results and variability are in
   `final-micro-results.md`; both paths use the actual model's BF16 bias values,
   with FI's FP32 representation prepared once before timing. Standalone
   mapping costs are per build/cache-group update, shared by that group's
   layers; end-to-end serving includes every actual mapping. Final serving:
   768 measured / 64 warmup, zero failures, actual 21,845 KV tokens matched
   across all audited launches. C1/C8 paired throughput +0.279%/+0.113%, with
   C8's second pair -0.208%; descriptive n=2/backend, no speedup claim.
   Quality raw T/FI 96/95; completed, marked correct 95/95; exact token outputs
   63/100. The sole raw loss is truncated/no-marker baseline question 209
   credited by fallback versus FI's completed wrong answer. No equivalence
   claim. Keep BF16's null-slot
   diagnostic; do not widen tolerances.
   Confirm runtime dispatch and document any actual CI hardware/coverage gap.
   Section 1.5 says to run `VLLM_GPU_SYNC_CHECK=error` "to confirm a concern";
   no new steady-state synchronization concern was identified in this code
   audit. If needed, use it in a separate short diagnostic smoke, not the timed
   comparison. It is not an unconditional requirement for every benchmark.
3. Code quality: production Ruff and syntax checks passed. No additional
   concatenation or contiguous copies in the adapter, no GPU-to-host tensor
   reads in the new steady-state path. The configuration field supplies the
   generated documentation and an explicit FP32-state CLI example. Required
   pre-commit hooks, manual mypy 3.12 on the three production files, and diff
   checks passed. The human submitter subsequently confirmed review/testing
   for this unchanged patch on 2026-10-07 Asia/Shanghai.
4. PR contents: local template-based draft links the takeover invitation and
   distinguishes existing work. Claims are restricted to opt-in FP32 support;
   measured cache-dependent gains/regressions, near-baseline serving and
   the full quality discrepancy, and
   the reused native runtime / DSL version mismatch are
   disclosed. Public evidence links are prepared and human review/testing
   confirmed. Before publication, ensure the
   material difference from the open predecessor is explained in its issue.

Actual serving then exposed a `dt_bias` dtype mismatch missed by FP32 fixtures.
Explicit FI now constructs that parameter in FP32; auto/Triton remain unchanged.
The actual checkpoint's 48 bias tensors are BF16, so promoted values are exact.
FP32-bias checkpoints can retain more precision than the native BF16-parameter
path and are outside this evaluation.
A constructor plus real sharded-loader regression passed for all three backends.
This fix adds no forward conversion or allocation. In particular,
the remap is refreshed in both `build` and `update_block_table`, capture uses
the same builder buffers, and mixed decode uses disjoint active state slots
and the existing decode-first output ordering. Full end-to-end evidence and
known coverage limits are in the final serving and quality reports.

Human review artifact: `review.patch` contains exactly the eight final changed
files against main `3e182185aa5d143b0e69c44607f58a0cc55f3971`, 38,980 bytes,
SHA256 `cca1d2ddf75bd0d6128f81ba985c3af335cadbb7cc8dcda0ac335437db8b7f8d`.
Per-file hashes are in `review-patch-manifest.json`. No commit or push was made.
