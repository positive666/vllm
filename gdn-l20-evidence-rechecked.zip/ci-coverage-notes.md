# Read-only CI coverage check

Baseline: `3e182185aa5d143b0e69c44607f58a0cc55f3971`.
Inspected the current isolated source and Buildkite test-area declarations.
No tests were run during this audit, and no source, tests or CI configuration
were changed. No material test-selection or all-skipped issue was identified.

| Changed suite | Existing CI job and command | Effective coverage |
| --- | --- | --- |
| `tests/kernels/fla/test_fused_sigmoid_gating_delta_rule.py` | B200 FLA Ops, `.buildkite/test_areas/kernels.yaml:202-212`, `pytest -v -s kernels/fla` | Whole directory is collected without exclusions. B200 satisfies CUDA SM89+, so the 14 configuration/constructor cases and 5 GPU parity/graph cases are eligible. The MI355 mirror intentionally skips those 5 CUDA-specific cases and keeps the CPU cases. |
| `tests/kernels/mamba/test_gdn_forward_core_split.py` | H200 MIG 35GB Mamba Kernels, `kernels.yaml:501-511`, `pytest -v -s kernels/mamba` | Whole directory is collected without exclusions. SM90 passes the widened SM89+ guard: 8 Triton and 4 FlashInfer cases are eligible. H200 uses the Triton prefill reference; SM10x selects CuteDSL. The AMD mirror skips this CUDA-only module intentionally. |
| `tests/kernels/mamba/test_gdn_fused_mtp.py` | Same Mamba job | Existing SM80+ eligibility and native-op checks are unchanged. The fixture now includes the real decode CustomOp required by the layer. Native CUDA 13 execution remains outside the local runtime evidence. |
| `tests/v1/attention/test_gdn_metadata_builder.py` | H100/B200 V1 Attention shards, `.buildkite/test_areas/attention.yaml:5-16,34-44`, `pytest -v -s v1/attention ...` | The directory jobs and AMD mirrors include this file; their exclusions do not remove GDN metadata. Its 4 new cases use CPU tensors and do not import or launch FlashInfer, so CUDA capability checks cannot skip them. |
| `tests/test_config.py` | H200 MIG 18GB Engine Core, `.buildkite/test_areas/engine.yaml:5-29`, command includes `test_config.py` | The hash/invalid-backend case has no platform skip. Changed `vllm/config/` files select this job. |

The miscellaneous B200 kernel job excludes `kernels/fla` and `kernels/mamba`
(`kernels.yaml:233-249`) because the dedicated jobs above collect them; those
exclusions do not leave these changes uncovered. FLA's broad `vllm/` and
`tests/kernels/` dependencies select its job for this diff. Mamba's GDN source
and test dependencies likewise select its job. The metadata source/test diff
selects both V1 Attention jobs.

`requirements/cuda.txt:17-18` already pins both FlashInfer Python and cubin
packages to `0.7.0.post1`. The GPU tests use `pytest.importorskip` only for the
module import; incompatible APIs or numerical failures are not converted to
skips. `has_device_capability(89)` compares integer capabilities with `>=`
(`vllm/platforms/interface.py:447-467`), so both SM90 and SM100 satisfy it.
The production explicit FlashInfer gate uses that same SM89+ condition.
`auto`/`triton` preserve native selection and avoid FlashInfer import. Existing
platform code and global collection hooks are unchanged by the diff.

These declarations establish intended collection, not an observed B200,
H200 or AMD CI pass. Root's actual L20 final focused run passed 31 cases.
The separate exact-main native MTP control reproduced 7 passed, 7 skipped
and 2 failed, with missing `fused_gdn_decode_post_conv_mtp` as the skip reason.
`CMakeLists.txt:1126-1155` builds that native source only for CUDA compiler
13.0+, while the local extension uses the CUDA 12.9 environment. The default
Dockerfile requests CUDA 13.0.3 (`docker/Dockerfile:25`), so a normal CUDA 13
CI build can include that path; this audit does not claim it was executed.
