"""Recompute compact summaries from immutable production-wrapper evidence."""

import argparse
import hashlib
import json
import statistics
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("result", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = json.loads(args.result.read_text(encoding="utf-8"))
    assert report["all_correctness_passed"]
    assert all(row["passed"] for row in report["cases"])
    result = {
        "input_sha256": hashlib.sha256(args.result.read_bytes()).hexdigest(),
        "source_sha256": report["source_file_sha256"],
        "harness_sha256": report["harness_sha256"],
        "correctness_cases": len(report["cases"]),
        "steps_per_trajectory": report["args"]["steps"],
        "rows": [],
        "metadata_mapping_us": {},
        "max_trajectory_errors": {},
    }
    for case in report["cases"]:
        for field, metrics in case["correctness"]["trajectory"].items():
            maxima = result["max_trajectory_errors"].setdefault(field, {})
            for key in ("max_abs", "relative_l2", "pointwise_over_threshold"):
                value = metrics[key]
                if value > maxima.get(key, -1):
                    maxima[key] = value
                    maxima[key + "_case"] = {
                        name: case[name] for name in ("batch", "index_dtype", "padding")
                    }
        if "timings" not in case:
            continue
        result["metadata_mapping_us"][case["batch"]] = case["metadata_mapping_timing"]
        for cache, arms in case["timings"].items():
            row = {"batch": case["batch"], "cache": cache, "arms": {}}
            for backend, rounds in arms.items():
                medians = [sample["median_us"] for sample in rounds]
                assert all(
                    sample["rotations"] == rounds[0]["rotations"] for sample in rounds
                )
                row["arms"][backend] = {
                    "median_of_round_medians_us": statistics.median(medians),
                    "round_medians_us": medians,
                    "round_median_minmax_us": [min(medians), max(medians)],
                    "round_p10_p90_us": [
                        [sample["p10_us"], sample["p90_us"]] for sample in rounds
                    ],
                    "sample_counts": [sample["samples"] for sample in rounds],
                    "rotations": rounds[0]["rotations"],
                    "active_state_MiB": rounds[0]["active_state_bytes_per_rotation"]
                    / 2**20,
                    "rotated_active_state_MiB": rounds[0]["rotated_active_state_bytes"]
                    / 2**20,
                    "state_read_write_GB_per_s": statistics.median(
                        sample["state_read_write_GB_per_s"] for sample in rounds
                    ),
                    "timers": [sample["timer"] for sample in rounds],
                }
            baseline = row["arms"]["triton"]["median_of_round_medians_us"]
            candidate = row["arms"]["flashinfer"]["median_of_round_medians_us"]
            row["flashinfer_latency_reduction_percent"] = 100 * (
                1 - candidate / baseline
            )
            row["flashinfer_speedup"] = baseline / candidate
            result["rows"].append(row)
    if args.output is not None:
        with args.output.open("x", encoding="utf-8") as handle:
            json.dump(result, handle, indent=2)
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
