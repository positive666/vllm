# Final FlashInfer GDN L20 evidence

Start with final-serving-results.md, final-micro-results.md and review.patch.
evidence-manifest.json records every included file's SHA256.
Serving uses four independent ABBA launches and the same 100-question
GSM8K subset. Raw parsed and conservative completed-answer scores are
reported separately. No accuracy-equivalence claim is made.

The native extension is reused from the identified CUDA12.9 wheel.
Existing MTP failures were reproduced on baseline and the patch before
the final bias fix; they are distinctly labeled diagnostic logs.
This is not new passing MTP coverage.

Only explicitly whitelisted final evidence and decision diagnostics
are included. Private remote operations, credentials, source archives
and preliminary serving/microbenchmark data are excluded.
