# Official FI FP32-state bias compilation contract

This is a static source and provenance audit, not an additional GPU experiment.
The public API documents `dt_bias` as BF16 or FP32. The official FP32-state
pretranspose implementation initially compiles the actual `dt_bias` dtype
from DLPack; it does not unconditionally declare FP32 input.
[Official API](https://github.com/flashinfer-ai/flashinfer/blob/v0.7.0.post1/flashinfer/gdn_decode.py#L507)

`official_gdn_decode_pretranspose.py` is the actual wheel file downloaded for
inspection. Its SHA256 is
`0547298823f4cdc1434c079749fe62a1bcafbd5aae3f129321431f414751b84d`,
matching the runtime probe's official RECORD entry.

The cached specialization key at lines 1003–1017 includes dimensions,
`q.dtype`, scale, Q/K normalization, pool mode and inner state strides. It
omits `dt_bias.dtype`. The persistent kernel name at lines 903–933 receives
this same key. Compilation at line 1061 consumes the actual `dt_bias` tensor
via `from_dlpack`, and lines 1081–1114 load or build that named callable.
The runtime invocation at lines 1121–1135 passes the actual tensor directly.
[Official kernel](https://github.com/flashinfer-ai/flashinfer/blob/v0.7.0.post1/flashinfer/gdn_kernels/gdn_decode_pretranspose.py#L1003)

Consequently BF16/FP32 bias values can share a cached specialization name even
though their tensor argument signatures differ. Reusing a specialization
compiled with FP32 bias for BF16 bias can produce the observed TVM tensor
argument dtype mismatch. The missing key explains this possible collision;
this audit does not establish every prior cache-population event or prove
that a clean cache must reject BF16 bias. No upstream cache code was changed.

The current integration initializes FI-only `dt_bias` as FP32 to keep its
compile/runtime dtype stable, with no hot-path cast. The actual checkpoint's
48 biases are BF16, so FI's promotion preserves exactly the values seen by
Triton. Final correctness and serving are validated using that contract.
Do not describe the failure as a universal FI API prohibition on BF16 bias.
