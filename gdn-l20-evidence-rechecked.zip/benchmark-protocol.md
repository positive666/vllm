# FlashInfer GDN continuation: L20 validation protocol

This directory contains experiment artifacts only. The production source is
`D:/code/vllm/.codex_tmp/gdn-flashinfer-takeover-20261006`, based on upstream
main `3e182185aa5d143b0e69c44607f58a0cc55f3971`. Record the final source diff and
its file hashes before running; do not label the changed source as unchanged
main. Only the root agent executes GPU work and manages the authorized container.

## Correctness and microbenchmark

`benchmark_gdn_takeover.py` constructs the actual production `GDNDecode` for
`triton` and `flashinfer`; no substitute FlashInfer or CUDA implementation is
used. It uses the local FP8 checkpoint's dimensions H=16/HV=48/K=V=128,
TP=1, BF16 packed QKVZ
and BA views with production-style row strides. The final supported matrix uses
FP32 state pools with unused slots and trailing padding in each cache page.
BF16 state is an unsupported diagnostic, not production coverage.
The folder is labeled `Qwen3.8-27B-FP8`; its config identifies
`Qwen3_5ForConditionalGeneration` / `qwen3_5`, used in text-only mode.
The folder name is not evidence of an official Qwen3.8 model identity.

Final GDN source SHA256 is
`674ea2aef2cf945e23b37bb1bc3a9e6a7c861df20561eebbc4131ee6b5faa963`.
All 48 actual checkpoint `dt_bias` tensors are BF16. The fixture uses BF16
representable values for Triton and an exact FP32 promotion for FlashInfer,
allocated before timing; the FP64 reference reads those same values. This
integration constructs its FI-only `dt_bias` parameter as FP32 once during
initialization to keep the compiled signature stable. The public FI API allows
BF16 or FP32 bias, but its specialization key omits bias dtype; do not describe
the observed cached-signature mismatch as a universal FP32 API requirement.
See `fi-bias-cache-review.md`. There is no per-forward dtype conversion. Keep the earlier
FP32-synthetic-bias microbenchmark and pre-fix A1 as preliminary artifacts only.

The timed boundary is post-convolution gate + Q/K norm + recurrent update +
the same gated output RMSNorm. Convolution, projection and per-step metadata
construction are excluded. The pad-index mapping is measured as one remap for
one metadata builder/cache group. Its result is reused by that group's layers
within the model step. Multiple GDN cache groups can require multiple builders
or remaps; do not assume a single global model-step call or charge it once per
layer. Output allocation is excluded. For padded correctness cases,
the raw output is initialized as the production Qwen caller does. Output parity
is checked only on positive-index rows because serving ignores padded outputs.
Every inactive state slot, including slot 0, and cache-page padding must remain
bitwise unchanged; this requirement is never omitted to make a backend pass.

FlashInfer v0.7.0.post1's BF16 API explicitly redirects a negative read index to
the sacrificial slot 0, updates that slot, and leaves padded outputs undefined.
Its FP32 path skips negative-index reads/writes. Consequently the BF16 padding
case can fail this integration's state-preservation contract even after
correcting output comparison. Preserve the failing diagnostic and restrict the
production opt-in to supported state dtypes until a separate null-buffer design
is validated. [Official FlashInfer API source](https://github.com/flashinfer-ai/flashinfer/blob/v0.7.0.post1/flashinfer/gdn_decode.py#L550)

First run a cheap correctness screen using the normal owned `uv` environment
and `PYTHONPATH=/source`. The reused native extension is an identified source
`.so` symlink. Final commands do not use the preliminary bootstrap or import
shims. Inside the container:

```sh
uv run --offline --no-project /cache/gdn-runtime/bin/python /artifacts/benchmark_gdn_takeover.py \
  --source-head 3e182185aa5d143b0e69c44607f58a0cc55f3971 \
  --batches 1,8 --dtypes float32 --index-dtypes int32 \
  --steps 16 --correctness-only --output /results/final/correctness-cheap.json
```

Then run full correctness and, only after every case passes, three alternating
rounds of warm/cold timing:

```sh
uv run --offline --no-project /cache/gdn-runtime/bin/python /artifacts/benchmark_gdn_takeover.py \
  --source-head 3e182185aa5d143b0e69c44607f58a0cc55f3971 \
  --batches 1,8,32 --dtypes float32 --index-dtypes int32,int64 \
  --steps 128 --rounds 3 --output /results/final/micro-production-fp32.json
```

The first step checks FP64 mathematical references for raw output, normalized
output, and rounded stored state. The trajectory uses CUDA graphs, fresh random
inputs and changing request-to-slot mappings. FP32 state uses atol=rtol=1e-2,
matching the production parity tests. The
normalized output retains the same gate. Relative L2 must also be <1%. Null and
unused slots and cache-page padding must stay bitwise unchanged. Failure labels,
metrics, and up to five violating values are saved. All numerical case failures
are explored and retained; any failure prevents timing. CUDA faults abort the
process immediately. Do not widen tolerances to make a trajectory pass.

CUPTI with CUDA graphs is the default timer. Any helper warning that it falls
back to CUDA graph events is recorded in each timing entry and must be disclosed.
`--timer graph` explicitly selects events. Cold runs rotate pointer-distinct
active state buffers totaling >5x device L2. Compilation, allocation, reset,
random generation and logging are outside timing. State read/write GB/s is a
theoretical traffic estimate and can exceed HBM bandwidth in warm-cache runs.

These numbers compare public production defaults. They do not establish that
the implementation is optimal or that FlashInfer wins every shape. A negative
result should trigger a small documented tuning investigation of both arms,
not a universal performance conclusion or an automatic `auto` switch.

The production eligibility gate is restricted to FP32 state. Run the complete
supported correctness/performance matrix with `--dtypes float32`. Keep the
original BF16 diagnostic separate and test that explicit unsupported BF16 opt-in
raises a clear error. Do not label the final FP32-only result as BF16 coverage.

## Actual serving and quality

Use the same actual FP8 checkpoint, source, image, FP8 GEMM backend, state dtype,
TP=1, seed=42, tokenizer, scheduler/KV limits and compilation/graph settings.
All final launches fix the KV cache at 64 blocks; preserve the actual startup
token capacity as evidence rather than assuming it from CLI arguments.
Disable prefix caching. Change only `--kernel-config`'s
`gdn_decode_backend`. Keep `VLLM_GDN_DECODE_KERNEL`/MTP configuration identical.
Use a separate fresh process/cache for every arm and preserve startup logs,
backend selection, source/native-library hashes, package versions and GPU
identity. No timing observer hooks should run in the measured server.

The owned runtime is `/cache/gdn-runtime`; all Python commands use `uv` with
that environment's interpreter. FlashInfer 0.7.0.post1 must retain its official
wheel files, checked against wheel RECORD entries, with no source patches or
import shims replacing FI behavior. Record its matching cubin/JIT dependencies
and CUTLASS DSL 4.7.1. The precompiled vLLM native extension is reused and must
be identified by path/hash/version; the Python overlay is current main plus
this patch. This is explicitly a mixed precompiled runtime validation, not a
native build of current main. Backend A/B uses exactly the same native binary.

Run independent launches in ABBA order: `triton-a1`, `flashinfer-b1`,
`flashinfer-b2`, `triton-a2`. All four final launches use the same final source
hash above; exclude the preliminary pre-fix Triton A1 from this comparison.
The shared fixture is created once and never regenerated for another backend:

```sh
uv run --offline --no-project /cache/gdn-runtime/bin/python /artifacts/http_bench_client.py fixture \
  --model qwen-fp8 --fixture /results/final/http-fixture.json

uv run --offline --no-project /cache/gdn-runtime/bin/python /artifacts/http_bench_client.py bench \
  --model qwen-fp8 --fixture /results/final/http-fixture.json --arm triton-a1 \
  --requests 32 --warmup-requests 8 \
  --server-evidence /results/final/serve-final-triton-a1.json \
  --output-dir /results/final/http
```

Repeat the `bench` command with the appropriate arm after each fresh server
launch. Every launch runs C1 and C8, three measured rounds per concurrency and
eight warmup requests per concurrency: 768 measured and 64 warmup requests over
the four independent launches. Each request has exactly 512 input and
64 output tokens, temperature=0, seed=42, no EOS early stop. The client verifies
returned prompt IDs, output IDs, usage and terminal SSE state. It records raw
outputs, TTFT, token-chunk TPOT, throughput and failures. TPOT uses the interval
between first and last token-ID chunks divided by 63; it is not pure inter-token
latency when an SSE event contains multiple tokens. Closed-loop C8 arrivals
exercise new prefills while other requests continue decoding.

Report both per-launch and per-round numbers rather than presenting repeated
requests from one process as independent hardware experiments. Compare C1/C8
TTFT/TPOT/throughput separately and disclose any failure or throughput regression.
Exact token-ID comparison is a useful observable, not an accuracy metric.

Run the fixed arithmetic quality screen on each backend, preserving each answer
and token IDs. It is a smoke screen rather than a model accuracy benchmark:

```sh
uv run --offline --no-project /cache/gdn-runtime/bin/python /artifacts/quality_http.py \
  --arm triton --model qwen-fp8 --output /results/quality-fixed-triton.json
```

For model evaluation, reuse a cached GSM8K test JSONL with known provenance,
hash it, and run the identical seeded 100-example zero-shot subset on each arm:

```sh
uv run --offline --no-project /cache/gdn-runtime/bin/python /artifacts/quality_http.py \
  --arm triton --model qwen-fp8 --dataset /cache/gsm8k-test.jsonl \
  --samples 100 --max-tokens 1750 --concurrency 8 \
  --server-evidence /results/final/serve-final-triton-a1.json \
  --output /results/final/quality-triton.json
```

For FlashInfer use `--arm flashinfer`, the B1 server-evidence path and
`/results/final/quality-flashinfer.json` after launching that backend. Compare
parsed answers, accuracy, truncation/unparsed counts, and raw
tokens on matched questions. Disclose this bounded subset and zero-shot method;
it cannot establish statistical quality equivalence. Investigate output or
accuracy changes rather than replacing the dataset or selecting favorable rows.
The final 1,750-token budget is fixed for both backends before the final A/B;
the preliminary 1,024-token baseline is retained separately and excluded.
Preserve final truncated and unparsed outputs; do not increase one arm's budget
or filter questions after inspecting backend differences.
If H20 becomes available, run a separately labeled SM90 validation; L20 evidence
does not imply H20 behavior or performance.

Use the final result directory explicitly when summarizing, so preliminary
artifacts cannot be selected accidentally:

```sh
uv run --offline --no-project /cache/gdn-runtime/bin/python /artifacts/summarize_serving.py \
  --results-dir /results/final/http --quality-dir /results/final \
  --evidence-dir /results/final --logs-dir /logs \
  --source-manifest /artifacts/source-manifest.json \
  --output /results/final/serving-summary.json
```

The parser accepts `http-{arm}.json` or `{arm}.json`, recomputes each request's
metrics and hashes, verifies equal commands/runtime/workload, and preserves
per-round values and per-launch medians. Missing final files fail closed unless
an explicitly labeled `--allow-partial` report is requested.
Final logs are named `serve-final-{arm}.log`; completed supervisor records are
`serve-final-{arm}.json`. Audit their hashes against the completed records,
match embedded ready snapshots, and check all three production file hashes
against the final manifest. Observe and compare the actual KV token capacities
from all four logs. An incomplete log/evidence audit must never be described as
matched KV capacity, even if all HTTP result files are available.
