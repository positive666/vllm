# Official FI FP32 pool-offset audit

The running FlashInfer 0.7.0.post1 pretranspose source is verified against the
official wheel RECORD by `runtime-probe.json`:

`flashinfer/gdn_kernels/gdn_decode_pretranspose.py`

SHA256: `0547298823f4cdc1434c079749fe62a1bcafbd5aae3f129321431f414751b84d`.

Both small/large FP32 kernel branches widen the loaded read and write pool
indices to Int64 before indexing the strided state pool. The 4D view/local-tile
address calculation therefore receives an Int64 index before multiplying its
page stride; it is not a cast of an already-overflowed Int32 offset.
[Small branch](https://github.com/flashinfer-ai/flashinfer/blob/v0.7.0.post1/flashinfer/gdn_kernels/gdn_decode_pretranspose.py#L137),
[large branch](https://github.com/flashinfer-ai/flashinfer/blob/v0.7.0.post1/flashinfer/gdn_kernels/gdn_decode_pretranspose.py#L423).

This is source/provenance confirmation of the upstream large-offset fix. The
current L20 correctness pool is small and does not independently exercise an
element offset beyond INT32_MAX. No extra GPU allocation or runtime case was
introduced while serving was running; do not advertise a large-offset GPU
regression test as executed in this experiment.
