# Independent review of the FP32 FlashInfer GDN opt-in

Baseline: `3e182185aa5d143b0e69c44607f58a0cc55f3971`.
Reviewed the final eight-file diff and the production model-runner call sites.
No unresolved material correctness defect was identified in this revision.
The bias initialization fix and the three real-constructor/loader regression
cases below are included in the reviewed source.

- `auto` selects the same packed Triton operation as before. The mixed Triton,
  prefill, speculative and MTP implementations are unchanged. ROCm's default
  route does not import FlashInfer; explicit FlashInfer fails on non-CUDA.
- BF16 SSM is rejected before API lookup. This preserves the reserved null
  slot: FlashInfer's BF16 negative-index path would write slot zero. FP32
  receives `-1` for both native null and padding indices, while convolution
  and native kernels keep their original indices.
- Packed QKV/Z and gate views are passed without new data copies. The state
  pool keeps its existing `[pool, value_heads, value_dim, key_dim]` layout.
  The per-rank value-head alignment guard matches the tested FP32 gate layout.
- Metadata mapping happens after state indices are gathered and graph buffers
  are staged. `update_block_table` maps into the destination builder's own
  preallocated buffer. Model Runner V2's cache-group reuse and aligned-index
  preparation therefore preserve group ownership and stable graph pointers.
- The CustomOp's explicit dispatch matches the nearby prefill CustomOp's
  convention. Unsupported explicit configuration and missing pool APIs reject
  early; they do not silently activate another decode backend.

Full-model boot initially failed at `serve-flashinfer-b1.log:382`: FlashInfer's
cached small-batch compiled signature expected FP32 `dt_bias` on argument #3.
The FlashInfer API does not unconditionally require FP32 bias: its wrapper
creates the signature from `from_dlpack(dt_bias)`, but its compile cache key
omits `dt_bias.dtype` (`official_gdn_decode_pretranspose.py:1003-1016,1061`).
Consequently a compiled FP32 signature can be reused with incompatible BF16
bias. The real layer created BF16 bias under the loader's default dtype and
the sharded loader's `copy_` retained that dtype; the earlier fixtures supplied
FP32 directly and missed the real constructor. The revised constructor creates
FP32 bias only for explicit FlashInfer, normalizing this cached signature;
auto/Triton retain their original default dtype. Loading and decode forward
do not add per-step casts. Root inspected the actual checkpoint and reported
all 48 bias tensors are BF16, so promotion preserves their stored values
exactly. Three passing CPU cases construct a real tiny layer under BF16
defaults, load the rank-one shard through its real weight loader, and compare
all loaded values exactly while checking the backend-specific parameter dtype.

Root's final remote focused run passed **31 tests: 19 adapter/constructor
cases and 12 mixed model-path cases**. Existing numerical tolerances were
preserved. The captured `mixed-mtp-final.log` also independently shows all
12 mixed cases passing before the bias constructor fix.
MTP results are **7 passed, 7 skipped, 2 failed**, not a full pass. Both failures
are the existing pure-MTP assertion `fused_mock.call_count == 1`, with actual
zero calls. The 7 ratio cases skip when the precompiled extension lacks
`torch.ops._C.fused_gdn_decode_post_conv_mtp`. The production feature guard
requires that same symbol and falls back when it is absent. Both the guard
and the failing assertions exist unchanged in the baseline. Baseline
`CMakeLists.txt:1126-1155` only selects the fused GDN CUDA source when the CUDA
compiler is at least 13.0. The recorded runtime uses Torch `2.13.0+cu129` and
CUDA 12.9; the absent fused MTP symbol is consistent with that build gate.
This does not indicate a new FlashInfer regression, and the fused MTP path
cannot be validated in this native-extension configuration. The actual exact
baseline control run now recorded in `mtp-baseline.log` reproduces the same
**7 passed, 7 skipped, 2 failed** on unmodified main in 8.10 seconds. Its skip
summary explicitly reports `fused GDN decode MTP op is not built`.

The actual installed official FlashInfer FP32 kernel source was subsequently
retrieved as `official_gdn_decode_pretranspose.py`; its SHA256 is
`0547298823f4cdc1434c079749fe62a1bcafbd5aae3f129321431f414751b84d`,
matching `runtime-probe.json`'s installed wheel record. Both small-batch and
large-batch kernels widen read and write pool indices with `cutlass.Int64`
before CuTe pool indexing (`148-149` and `461-462`). Pool addressing and local
tile selection occur after those casts (`161-163` and `474-476`). The compile
wrapper also represents the pool page stride as `cute.sym_int64` (`1046`).
Consequently this inspected runtime source does not retain the Int32
index-times-stride overflow underlying the earlier large-pool issue. No GPU
stress result is claimed for this source inspection.

Final serving subsequently completed four graph-enabled full-model launches
and a matched 100-question quality screen; see the final serving and quality
reports. No H20 or ROCm runtime result was inspected. A current-main native
build, main's CuTeDSL 4.8 pin and native fused MTP remain outside coverage.
The large-pool source check above establishes the addressing implementation
for the recorded FlashInfer runtime, not a large-pool GPU stress result.

FP32 bias stabilizes this adapter's own signature; it does not fix the upstream
cache key or establish compatibility with a shared cache populated by external
BF16-bias calls. The final fresh-launch validation used this adapter's constant
FP32 bias representation.

The follow-up read-only CI selection audit is recorded in
`ci-coverage-notes.md`. The existing B200 FLA, H200 Mamba, V1 Attention and
Engine Core jobs collect the changed suites; the CUDA guards do not skip all
new valid cases on those NVIDIA jobs. No new CI job or source change was
needed. This declaration-level check does not claim a CI execution result or
close the native CUDA 13 runtime coverage gap.

Reviewed production SHA256:

```text
vllm/config/kernel.py
6d9283f91177b8a28cdf0cb51c761ad8fd37bbb96948ac20a852c81bccd33a0c
vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py
674ea2aef2cf945e23b37bb1bc3a9e6a7c861df20561eebbc4131ee6b5faa963
vllm/v1/attention/backends/gdn_attn.py
0a7989cfdc2f9d764ca5c716814e500406a1641b7a2dcd1f18d128038c9920e8
```
