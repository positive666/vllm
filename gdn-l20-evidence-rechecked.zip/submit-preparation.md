# New PR submission preparation

Local preparation only. No GitHub comment, commit, push, or PR has been created.

Proposed title:

> [Kernel] Add opt-in FlashInfer GDN decode for Qwen hybrid models

Create a new PR targeting `vllm-project/vllm:main` from the planned branch
`codex/gdn-flashinfer-takeover`. The implementation baseline is
`3e182185aa5d143b0e69c44607f58a0cc55f3971`. Keep the closed #53463 as context
for the takeover invitation; this preparation does not reopen it.

The reviewer invited a fresh integration in
[#53463, comment 6006969716](https://github.com/vllm-project/vllm/pull/53463#issuecomment-6006969716).
The explicit invitation is: "you can take over the work and open a new PR".
The successor to [#41966](https://github.com/vllm-project/vllm/pull/41966)
uses `GDNDecode(CustomOp)`, the existing `--kernel-config` interface, and the
main metadata builder's pooled-state remapping and CUDA-graph buffer reuse.
It includes ordinary decode in mixed prefill/decode batches. The older
[#41395](https://github.com/vllm-project/vllm/pull/41395) and
[#35292](https://github.com/vllm-project/vllm/pull/35292) use stale interfaces;
[#53645](https://github.com/vllm-project/vllm/pull/53645) integrates the
separate SM120 whole-layer `gdn_fused_decode_step`.

Read-only GitHub checks refreshed on 2026-10-06 UTC are recorded in
[duplicates-final.json](duplicates-final.json). #41966 remains **open and
Draft**, authored by `vadiklyutiy`, at the unchanged head
`866de584641bb99137cbb54b74f2c69b5f1894b2` (updated
2026-09-28T19:20:43Z). The new PR is a reviewer-invited successor to existing
work; do not describe it as an area with no existing PR. No additional fresh
pooled FlashInfer decode takeover was found in the recorded searches or the
latest #53463 conversation. The broad decode query was expanded beyond its
initial result cap; all final queries are below their limits.

[#60050](https://github.com/vllm-project/vllm/pull/60050) adds internal
checkpoints to the FlashInfer **prefill** route;
[#60105](https://github.com/vllm-project/vllm/pull/60105) reuses prefill lengths
and changes prefill gate conversion. These share source files but do not add
this pooled decode route. Their integration may require a mechanical rebase.

`auto` continues to use Triton. FlashInfer is opt-in with FP32 SSM state;
prefill and speculative/MTP kernel selection stay as before. The tested L20
configuration and current native-extension / CuTeDSL coverage limits are
documented in the PR draft. The complete four-launch comparison is close to
baseline: C1/C8 throughput +0.279%/+0.113%, with C8's second pair -0.208%.
There is no meaningful serving speedup or significance claim.
The reviewer requests microbenchmark and end-to-end performance evidence.
Changing `auto` is conditional on consistent superiority, not a requirement
for taking over the integration. Report small or absent end-to-end gains
directly and retain Triton as the default.

Final evidence is complete locally: 95 targeted tests passed; the known MTP
7 pass / 7 skip / 2 failure outcome is reproduced on unchanged main; ten FP32
cases passed 128-step trajectories; all 768 measured / 64 warmup serving
requests succeeded with audited identical source/runtime/native and 21,845
actual KV tokens. The local checkpoint label is `Qwen3.8-27B-FP8`, config
`Qwen3_5ForConditionalGeneration`, text-only. The fixed quality screen is raw
Triton/FI 96/95, completed and final-marker correct 95/95, token-exact 63/100.
Keep question 209's truncated fallback baseline and completed wrong FI answer
visible; do not claim accuracy equivalence.
All 48 tested checkpoint biases are BF16 and are promoted exactly. FP32-bias
checkpoints can retain more bias precision than the native BF16-parameter path
and are not covered by this evaluation.

Suggested takeover note, to use only after the new PR exists:

> Following your invitation in #53463, I prepared a fresh FlashInfer GDN
> integration in <new PR URL>, succeeding #41966 against main. It uses
> `GDNDecode(CustomOp)` and `--kernel-config`, handles pooled-state padding
> and graph remapping, and covers ordinary decode in mixed batches. Triton
> remains the default; FlashInfer is an explicit FP32-state option. This
> differs from #53645's SM120 whole-layer kernel. The new PR contains the
> final validation results and AI-assistance disclosure.

The exact human-review artifact is [review.patch](review.patch), eight final
files and 38,980 bytes, SHA256
`cca1d2ddf75bd0d6128f81ba985c3af335cadbb7cc8dcda0ac335437db8b7f8d`.
[review-patch-manifest.json](review-patch-manifest.json) records every file
hash; [review-commands.md](review-commands.md) contains the focused commands.
The human submitter subsequently confirmed review/testing for this unchanged
new patch on 2026-10-07 Asia/Shanghai. The independent recheck adds no source
changes and is recorded in `independent-recheck-20261007.md`.

Public evidence links are prepared in [pr-description.md](pr-description.md).
Final duplicate checks are refreshed in `duplicate-checks-recheck.json` before
publication. If submission is delayed, refresh them again. If the final
source changes, regenerate the patch, hashes, and affected validation before
using this preparation.
